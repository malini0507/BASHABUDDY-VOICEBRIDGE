let chatHistory = [
  {
    sender: 'bot',
    textEn: "Hello! I am your BhashaBuddy Technical Learning Partner. You can ask me engineering questions or placement interview prep in English, Telugu, Hindi, or Tamil.",
    textRegional: "నమస్కారం! మీ సాంకేతిక సందేహాలు లేదా ఇంటర్వ్యూ ప్రిపరేషన్ ప్రశ్నలను ఇక్కడ అడగవచ్చు. నేను ఆంగ్లం మరియు తెలుగులో సమాధానమిస్తాను."
  }
];

function renderChatbot(state) {
  const t = (k) => window.LangManager.t(k);
  const lang = window.LangManager.getLang();

  const suggestions = [
    "What is a pointer?",
    "Explain recursion with base condition",
    "Difference between compiler and interpreter",
    "How to introduce myself in a technical interview?",
    "డేటాబేస్ అంటే ఏమిటి?",
    "స్టాక్ మరియు క్యూ మధ్య తేడా ఏమిటి?"
  ];

  return `
    <div class="max-w-3xl mx-auto space-y-4 animate-fadeIn">
      
      <!-- Chat Header -->
      <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-sky-500 text-white flex items-center justify-center font-bold text-lg shadow-md shadow-indigo-200">
            🤖
          </div>
          <div>
            <h2 class="text-base font-bold text-slate-900">${t('chatTitle')}</h2>
            <p class="text-xs text-slate-500">${t('chatSub')}</p>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button onclick="window.clearChatHistory()" class="text-xs text-slate-400 hover:text-rose-600 px-2.5 py-1 rounded-lg border border-slate-200 hover:border-rose-200 transition-colors">
            Clear
          </button>
          <span class="text-xs bg-emerald-50 text-emerald-700 font-bold px-2.5 py-1 rounded-full border border-emerald-200">
            ● Online
          </span>
        </div>
      </div>

      <!-- Quick Suggestion Chips -->
      <div class="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        ${suggestions.map(s => `
          <button 
            onclick="window.sendSuggestedPrompt('${s.replace(/'/g, "\\'")}')" 
            class="text-xs bg-white hover:bg-indigo-50 hover:text-indigo-700 text-slate-600 border border-slate-200 hover:border-indigo-300 px-3 py-1.5 rounded-full whitespace-nowrap transition-all shadow-sm"
          >
            💬 ${s}
          </button>
        `).join('')}
      </div>

      <!-- Chat History Box -->
      <div id="chatMessagesContainer" class="bg-slate-50/70 border border-slate-200 rounded-3xl p-4 sm:p-6 min-h-[380px] max-h-[500px] overflow-y-auto space-y-4">
        ${chatHistory.map(msg => `
          <div class="flex items-start gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}">
            
            ${msg.sender === 'bot' ? `
              <div class="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold shrink-0 mt-1 shadow-sm">
                BB
              </div>
            ` : ''}

            <div class="max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 shadow-sm space-y-2 ${
              msg.sender === 'user' 
                ? 'bg-indigo-600 text-white rounded-tr-none' 
                : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none'
            }">
              ${msg.sender === 'user' ? `
                <p class="text-xs sm:text-sm font-medium">${msg.text}</p>
              ` : `
                <div class="space-y-2 text-xs sm:text-sm">
                  <div class="leading-relaxed prose prose-sm text-slate-800">
                    ${msg.textEn.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>').replace(/\n\n/g, '<br/><br/>')}
                  </div>
                  
                  ${msg.textRegional ? `
                    <div class="pt-2 border-t border-slate-100 text-xs font-medium text-indigo-900 bg-indigo-50/70 p-2.5 rounded-xl">
                      ${msg.textRegional.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>')}
                    </div>
                  ` : ''}

                  <div class="pt-1 flex items-center justify-end">
                    <button 
                      onclick="window.SpeechService.speak('${msg.textEn.replace(/'/g, "\\'").replace(/"/g, '&quot;').replace(/\n/g, ' ')}')" 
                      class="text-[11px] text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1 bg-indigo-50/60 px-2 py-0.5 rounded-md transition-colors"
                    >
                      🔊 Listen in English
                    </button>
                  </div>
                </div>
              `}
            </div>

            ${msg.sender === 'user' ? `
              <div class="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center text-xs font-bold shrink-0 mt-1 shadow-sm">
                You
              </div>
            ` : ''}

          </div>
        `).join('')}
      </div>

      <!-- Chat Input Field -->
      <form onsubmit="window.handleChatSubmit(event)" class="flex items-center gap-2 bg-white p-2 rounded-2xl border border-slate-200 shadow-sm">
        <input 
          type="text" 
          id="chatInputBox" 
          placeholder="${t('chatPlaceholder')}" 
          class="flex-1 px-4 py-2 text-xs sm:text-sm bg-transparent focus:outline-none text-slate-800 placeholder-slate-400"
          autocomplete="off"
        />
        <button 
          type="submit" 
          class="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-200 transition-all flex items-center gap-1.5"
        >
          <span>${t('send')}</span>
          <span>&rarr;</span>
        </button>
      </form>

    </div>
  `;
}

window.renderChatbot = renderChatbot;

window.clearChatHistory = () => {
  chatHistory = [
    {
      sender: 'bot',
      textEn: "Chat cleared! Ask me any engineering question in English, Telugu, Hindi, or Tamil.",
      textRegional: "చాట్ క్లియర్ చేయబడింది! మీ ప్రశ్నను అడగండి."
    }
  ];
  window.renderApp();
};

window.handleChatSubmit = (e) => {
  e.preventDefault();
  const input = document.getElementById('chatInputBox');
  if (!input || !input.value.trim()) return;

  const userText = input.value.trim();
  input.value = '';

  chatHistory.push({ sender: 'user', text: userText });
  window.renderApp();

  const lang = window.LangManager.getLang();
  window.API.sendChatMessage(userText, lang).then(res => {
    if (res.success && res.data) {
      chatHistory.push({
        sender: 'bot',
        textEn: res.data.replyEn || res.data.reply || "I am happy to assist you!",
        textRegional: res.data.replyRegional || ""
      });
    }
    window.renderApp();
    const container = document.getElementById('chatMessagesContainer');
    if (container) container.scrollTop = container.scrollHeight;
  });
};

window.sendSuggestedPrompt = (prompt) => {
  const input = document.getElementById('chatInputBox');
  if (input) input.value = prompt;
  window.handleChatSubmit({ preventDefault: () => {} });
};
