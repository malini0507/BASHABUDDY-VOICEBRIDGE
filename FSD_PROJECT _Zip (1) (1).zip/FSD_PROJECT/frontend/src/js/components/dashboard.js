function renderDashboard(state) {
  const t = (k) => window.LangManager.t(k);
  const lang = window.LangManager.getLang();
  const progress = state.progress || {};
  const today = progress.today || { completedWords: 3, dailyGoal: 5, percentage: 60 };
  const stats = progress.stats || { totalAttempts: 12, averageScore: 88, masteredWords: 15, totalVocabInDeck: 51 };
  const dailyWords = state.dailyWords || [];

  return `
    <div class="space-y-8 animate-fadeIn">
      
      <!-- Hero Banner -->
      <div class="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 text-white p-6 sm:p-8 shadow-xl border border-indigo-500/20">
        <div class="absolute -right-10 -bottom-10 w-72 h-72 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div class="relative z-10 max-w-3xl">
          <div class="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white/10 backdrop-blur-md text-xs font-semibold text-indigo-200 mb-4 border border-white/10">
            <span>✨</span>
            <span>BhashaBuddy: VoiceBridge Jam</span>
          </div>
          <h1 class="text-2xl sm:text-4xl font-black tracking-tight text-white mb-3">
            ${t('welcomeTitle')}
          </h1>
          <p class="text-xs sm:text-sm text-indigo-100/90 leading-relaxed mb-6">
            ${t('welcomeSub')}
          </p>

          <div class="flex flex-wrap items-center gap-3">
            <button 
              onclick="window.switchTab('flashcards')" 
              class="px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-400 to-indigo-500 hover:from-sky-300 hover:to-indigo-400 text-slate-950 font-bold text-xs sm:text-sm shadow-lg shadow-sky-500/20 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
            >
              🚀 ${t('startPractice')}
            </button>
            <button 
              onclick="window.switchTab('pronunciation')" 
              class="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs sm:text-sm backdrop-blur-md border border-white/20 transition-all"
            >
              🎙️ Open Voice Lab
            </button>
            <button 
              onclick="window.switchTab('quiz')" 
              class="px-4 py-2.5 rounded-xl bg-transparent hover:bg-white/5 text-indigo-200 text-xs sm:text-sm font-medium transition-all"
            >
              📝 Take Daily Quiz
            </button>
            <button 
              onclick="window.switchTab('visualDict')" 
              class="px-4 py-2.5 rounded-xl bg-transparent hover:bg-white/5 text-purple-200 text-xs sm:text-sm font-medium transition-all"
            >
              🎨 Visual Schematics
            </button>
          </div>
        </div>
      </div>

      <!-- Quick Metrics Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <!-- Today's Goal -->
        <div onclick="window.switchTab('analytics')" class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between cursor-pointer hover:border-emerald-300 transition-all group">
          <div>
            <p class="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">${t('dailyGoal')}</p>
            <h3 class="text-2xl font-black text-slate-900 group-hover:text-emerald-600 transition-colors">${today.completedWords} <span class="text-xs font-normal text-slate-500">/ ${today.dailyGoal} words</span></h3>
            <div class="w-full bg-slate-100 rounded-full h-2 mt-2 w-32 overflow-hidden">
              <div class="bg-emerald-500 h-2 rounded-full transition-all duration-500" style="width: ${today.percentage}%"></div>
            </div>
          </div>
          <div class="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-lg">
            🎯
          </div>
        </div>

        <!-- Learning Streak -->
        <div onclick="window.switchTab('analytics')" class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between cursor-pointer hover:border-amber-300 transition-all group">
          <div>
            <p class="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">${t('streakDays')}</p>
            <h3 class="text-2xl font-black text-amber-600 group-hover:text-amber-700 transition-colors">${progress.user?.streak || 3} <span class="text-xs font-normal text-slate-500">days</span></h3>
            <p class="text-xs text-slate-400 mt-1">Keep it up today!</p>
          </div>
          <div class="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-xl">
            🔥
          </div>
        </div>

        <!-- Words Mastered -->
        <div onclick="window.switchTab('vocabulary')" class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between cursor-pointer hover:border-indigo-300 transition-all group">
          <div>
            <p class="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">${t('wordsLearned')}</p>
            <h3 class="text-2xl font-black text-indigo-600 group-hover:text-indigo-700 transition-colors">${stats.masteredWords || 15} <span class="text-xs font-normal text-slate-500">/ ${stats.totalVocabInDeck}</span></h3>
            <p class="text-xs text-slate-400 mt-1">Engineering terms</p>
          </div>
          <div class="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xl">
            📚
          </div>
        </div>

        <!-- Speech Accuracy -->
        <div onclick="window.switchTab('pronunciation')" class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between cursor-pointer hover:border-sky-300 transition-all group">
          <div>
            <p class="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">${t('accuracyRate')}</p>
            <h3 class="text-2xl font-black text-sky-600 group-hover:text-sky-700 transition-colors">${stats.averageScore || 88}%</h3>
            <p class="text-xs text-slate-400 mt-1">Levenshtein similarity</p>
          </div>
          <div class="w-12 h-12 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center text-xl">
            🎙️
          </div>
        </div>

      </div>

      <!-- Today's Daily 5 Words Deck -->
      <div class="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
        <div class="flex items-center justify-between mb-4">
          <div>
            <h2 class="text-lg font-bold text-slate-900 flex items-center gap-2">
              <span>🌟</span>
              <span>Today's Recommended Vocabulary Deck</span>
            </h2>
            <p class="text-xs text-slate-500">Curated micro-lesson: practice native pronunciation and regional meaning for these 5 terms.</p>
          </div>
          <button onclick="window.switchTab('flashcards')" class="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors">
            View All Cards &rarr;
          </button>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          ${dailyWords.slice(0, 5).map((w, idx) => `
            <div class="p-4 rounded-2xl border border-slate-100 bg-slate-50/70 hover:bg-white hover:border-indigo-200 hover:shadow-md transition-all group flex flex-col justify-between">
              <div>
                <div class="flex items-start justify-between mb-2">
                  <div>
                    <span class="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${w.difficulty === 'Beginner' ? 'bg-emerald-100 text-emerald-800' : w.difficulty === 'Intermediate' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'}">
                      ${w.difficulty}
                    </span>
                    <h3 class="text-lg font-black text-slate-900 mt-1 group-hover:text-indigo-600 transition-colors">
                      ${w.english_word}
                    </h3>
                    <p class="text-xs text-slate-500 font-mono">${w.phonetic_guide}</p>
                  </div>
                  <button 
                    onclick="window.SpeechService.speak('${w.english_word.replace(/'/g, "\\'")}')" 
                    class="p-2 rounded-lg bg-white border border-slate-200 text-indigo-600 hover:bg-indigo-50 shadow-sm transition-all"
                    title="Listen Pronunciation"
                  >
                    🔊
                  </button>
                </div>

                <div class="text-xs text-slate-700 bg-white p-2.5 rounded-xl border border-slate-100 mb-3">
                  <p class="font-bold text-indigo-900">
                    ${lang === 'te' ? w.telugu_meaning : lang === 'hi' ? w.hindi_meaning : lang === 'ta' ? w.tamil_meaning : w.definition}
                  </p>
                </div>
              </div>

              <div class="flex items-center gap-2 pt-2 border-t border-slate-100">
                <button 
                  onclick="window.openVoiceLabForWord('${w.english_word.replace(/'/g, "\\'")}', ${w.word_id})" 
                  class="flex-1 py-1.5 px-3 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                >
                  🎙️ Voice Lab
                </button>
                <button 
                  onclick="window.markLearned(${w.word_id})" 
                  class="py-1.5 px-3 rounded-xl border border-slate-200 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-300 text-slate-600 text-xs transition-colors"
                  title="Mark as Mastered"
                >
                  ✓
                </button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>

      <!-- 7 Engineering Modules Explorer -->
      <div class="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
        <h2 class="text-lg font-bold text-slate-900 mb-1">Explore by Engineering Domain</h2>
        <p class="text-xs text-slate-500 mb-4">Bilingual vocabulary curriculum organized into 7 progressive engineering units.</p>

        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          ${[
            { title: "Computer Fundamentals", count: 8, icon: "💻" },
            { title: "Programming Languages", count: 9, icon: "⚡" },
            { title: "Data Structures", count: 8, icon: "🌳" },
            { title: "Database Systems", count: 8, icon: "🗄️" },
            { title: "Computer Networks", count: 8, icon: "🌐" },
            { title: "Artificial Intelligence", count: 6, icon: "🤖" },
            { title: "Engineering Mathematics", count: 4, icon: "📐" }
          ].map(cat => `
            <div 
              onclick="window.filterByCategory('${cat.title}')" 
              class="p-4 rounded-2xl border border-slate-200 hover:border-indigo-300 hover:shadow-md cursor-pointer transition-all bg-gradient-to-b from-white to-slate-50 group"
            >
              <div class="text-2xl mb-2">${cat.icon}</div>
              <h3 class="text-xs sm:text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors leading-snug">
                ${cat.title}
              </h3>
              <p class="text-[11px] text-slate-500 mt-1 font-medium">${cat.count} Vocabulary Terms</p>
            </div>
          `).join('')}
        </div>
      </div>

    </div>
  `;
}

window.renderDashboard = renderDashboard;
