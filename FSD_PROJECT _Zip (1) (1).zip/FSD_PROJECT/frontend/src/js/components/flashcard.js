let currentCardIndex = 0;
let isFlipped = false;

function renderFlashcards(state) {
  const t = (k) => window.LangManager.t(k);
  const lang = window.LangManager.getLang();
  const words = state.vocabularyList || [];
  
  if (words.length === 0) {
    return `<div class="p-8 text-center text-slate-500">Loading flashcard deck...</div>`;
  }

  if (currentCardIndex >= words.length) currentCardIndex = 0;
  if (currentCardIndex < 0) currentCardIndex = words.length - 1;

  const word = words[currentCardIndex];

  let regionalMeaning = word.telugu_meaning;
  if (lang === 'hi') regionalMeaning = word.hindi_meaning;
  if (lang === 'ta') regionalMeaning = word.tamil_meaning;
  if (lang === 'en') regionalMeaning = word.definition;

  const progressPercent = Math.round(((currentCardIndex + 1) / words.length) * 100);

  return `
    <div class="max-w-2xl mx-auto space-y-5 animate-fadeIn">
      
      <!-- Top Deck Header -->
      <div class="flex items-center justify-between">
        <div>
          <h2 class="text-xl font-bold text-slate-900 flex items-center gap-2">
            <span>🃏</span>
            <span>Interactive 3D Flashcards</span>
          </h2>
          <p class="text-xs text-slate-500">Flip card to see vernacular translation, pronunciation guide, and engineering context.</p>
        </div>

        <div class="flex items-center gap-2">
          <span class="text-xs font-mono font-bold bg-slate-100 text-slate-700 px-3 py-1 rounded-full border border-slate-200">
            Card ${currentCardIndex + 1} / ${words.length}
          </span>
          <button 
            onclick="window.shuffleCards()" 
            class="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors" 
            title="Shuffle Deck"
          >
            🔀
          </button>
        </div>
      </div>

      <!-- Linear Deck Progress Bar -->
      <div class="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
        <div class="bg-indigo-600 h-1.5 rounded-full transition-all duration-300" style="width: ${progressPercent}%"></div>
      </div>

      <!-- Domain Category & Filter Strip -->
      <div class="flex flex-wrap items-center justify-between gap-2 bg-white p-3 rounded-xl border border-slate-200 text-xs">
        <div class="flex items-center gap-2">
          <span class="font-bold text-slate-600">Domain:</span>
          <select 
            onchange="window.filterDeckCategory(this.value)" 
            class="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-medium text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer"
          >
            <option value="All" ${state.selectedCategory === 'All' ? 'selected' : ''}>All 7 Domains</option>
            <option value="Computer Fundamentals" ${state.selectedCategory === 'Computer Fundamentals' ? 'selected' : ''}>Computer Fundamentals</option>
            <option value="Programming Languages" ${state.selectedCategory === 'Programming Languages' ? 'selected' : ''}>Programming Languages</option>
            <option value="Data Structures" ${state.selectedCategory === 'Data Structures' ? 'selected' : ''}>Data Structures</option>
            <option value="Database Systems" ${state.selectedCategory === 'Database Systems' ? 'selected' : ''}>Database Systems</option>
            <option value="Computer Networks" ${state.selectedCategory === 'Computer Networks' ? 'selected' : ''}>Computer Networks</option>
            <option value="Artificial Intelligence" ${state.selectedCategory === 'Artificial Intelligence' ? 'selected' : ''}>Artificial Intelligence</option>
            <option value="Engineering Mathematics" ${state.selectedCategory === 'Engineering Mathematics' ? 'selected' : ''}>Engineering Mathematics</option>
          </select>
        </div>

        <span class="text-slate-400 font-mono text-[11px]">
          [Spacebar] Flip • [← / →] Navigate
        </span>
      </div>

      <!-- 3D Interactive Flip Card -->
      <div class="perspective-1000 w-full min-h-[380px] cursor-pointer" onclick="window.toggleFlipCard()">
        <div id="flashcardElement" class="relative w-full h-full min-h-[380px] rounded-3xl transition-transform duration-500 transform-style-3d shadow-xl ${isFlipped ? 'rotate-y-180' : ''}">
          
          <!-- FRONT FACE (English Term & Phonetics) -->
          <div class="absolute inset-0 backface-hidden bg-gradient-to-br from-white via-slate-50 to-indigo-50/50 rounded-3xl p-8 border-2 border-indigo-100 flex flex-col justify-between shadow-lg">
            
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full ${word.difficulty === 'Beginner' ? 'bg-emerald-100 text-emerald-800' : word.difficulty === 'Intermediate' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'}">
                ${word.difficulty}
              </span>
              <span class="text-xs font-semibold text-indigo-700 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-100">
                ${word.category}
              </span>
            </div>

            <!-- Central Content -->
            <div class="text-center my-6">
              <h2 class="text-4xl sm:text-5xl font-black text-slate-900 tracking-tight mb-3">
                ${word.english_word}
              </h2>
              <div class="inline-flex items-center gap-2 bg-indigo-50 border border-indigo-200/80 px-4 py-1.5 rounded-full text-indigo-800 font-mono text-sm sm:text-base shadow-sm">
                <span>🗣️</span>
                <span>${word.phonetic_guide}</span>
              </div>
            </div>

            <!-- Front Bottom Bar -->
            <div class="flex items-center justify-between border-t border-slate-200/70 pt-4" onclick="event.stopPropagation()">
              <div class="flex items-center gap-2">
                <button 
                  onclick="window.SpeechService.speak('${word.english_word.replace(/'/g, "\\'")}', 1.0)" 
                  class="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-200 flex items-center gap-1.5 transition-all"
                >
                  🔊 Listen (1.0x)
                </button>
                <button 
                  onclick="window.SpeechService.speak('${word.english_word.replace(/'/g, "\\'")}', 0.75)" 
                  class="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-colors"
                  title="Slow Pronunciation (0.75x)"
                >
                  🐢 0.75x
                </button>
              </div>

              <div class="text-xs text-indigo-600 font-semibold flex items-center gap-1 animate-pulse" onclick="window.toggleFlipCard()">
                <span>${t('flipCard')}</span>
                <span>↻</span>
              </div>
            </div>

          </div>

          <!-- BACK FACE (Vernacular Meaning & Example) -->
          <div class="absolute inset-0 backface-hidden rotate-y-180 bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 text-white rounded-3xl p-8 border-2 border-indigo-500/40 flex flex-col justify-between shadow-xl">
            
            <div class="flex items-center justify-between">
              <span class="text-xs font-semibold text-indigo-300">
                ${word.english_word} • Meaning & Context
              </span>
              <button 
                onclick="event.stopPropagation(); window.toggleFlipCard()" 
                class="text-xs text-indigo-300 hover:text-white px-2.5 py-1 rounded-lg bg-white/10"
              >
                Front Face ↻
              </button>
            </div>

            <!-- Regional Meaning Body -->
            <div class="space-y-3.5 my-2">
              <div class="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/10">
                <p class="text-[10px] uppercase tracking-wider text-indigo-300 font-bold mb-1">
                  Regional Translation (${lang.toUpperCase()}):
                </p>
                <p class="text-base sm:text-lg font-bold text-amber-300 leading-relaxed">
                  ${regionalMeaning}
                </p>
              </div>

              <div>
                <p class="text-[10px] uppercase tracking-wider text-indigo-300 font-semibold mb-1">
                  Engineering Definition:
                </p>
                <p class="text-xs sm:text-sm text-slate-200 leading-normal">
                  ${word.definition}
                </p>
              </div>

              <div class="bg-indigo-950/70 p-3 rounded-xl border border-indigo-800/50 text-xs flex items-center justify-between gap-2">
                <div>
                  <span class="text-emerald-400 font-bold">Context:</span>
                  <span class="text-slate-300 italic">"${word.example_sentence}"</span>
                </div>
                <button 
                  onclick="event.stopPropagation(); window.SpeechService.speak('${word.example_sentence.replace(/'/g, "\\'")}')" 
                  class="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white shrink-0"
                  title="Listen Example Sentence"
                >
                  🔊
                </button>
              </div>
            </div>

            <!-- Back Bottom Actions -->
            <div class="flex items-center justify-between border-t border-white/10 pt-4" onclick="event.stopPropagation()">
              <button 
                onclick="window.openVoiceLabForWord('${word.english_word.replace(/'/g, "\\'")}', ${word.word_id})" 
                class="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center gap-1.5"
              >
                🎙️ Practice Voice
              </button>

              <button 
                onclick="window.markLearned(${word.word_id})" 
                class="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-medium text-xs transition-colors flex items-center gap-1"
              >
                ✓ ${t('markMastered')}
              </button>
            </div>

          </div>

        </div>
      </div>

      <!-- Navigation Arrows Strip -->
      <div class="flex items-center justify-between pt-2">
        <button 
          onclick="window.prevCard()" 
          class="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-semibold text-sm shadow-sm transition-all"
        >
          &larr; Previous Word
        </button>

        <button 
          onclick="window.toggleFlipCard()" 
          class="px-4 py-2 rounded-xl text-xs font-semibold text-indigo-600 hover:bg-indigo-50 transition-colors"
        >
          Flip Card [Space]
        </button>

        <button 
          onclick="window.nextCard()" 
          class="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm shadow-md shadow-indigo-200 transition-all"
        >
          Next Word &rarr;
        </button>
      </div>

    </div>
  `;
}

window.renderFlashcards = renderFlashcards;
window.toggleFlipCard = () => {
  isFlipped = !isFlipped;
  const el = document.getElementById('flashcardElement');
  if (el) {
    if (isFlipped) el.classList.add('rotate-y-180');
    else el.classList.remove('rotate-y-180');
  }
};
window.nextCard = () => {
  isFlipped = false;
  currentCardIndex++;
  window.renderApp();
};
window.prevCard = () => {
  isFlipped = false;
  currentCardIndex--;
  window.renderApp();
};
window.shuffleCards = () => {
  if (window.appState && window.appState.vocabularyList) {
    window.appState.vocabularyList.sort(() => 0.5 - Math.random());
    currentCardIndex = 0;
    isFlipped = false;
    window.renderApp();
  }
};
