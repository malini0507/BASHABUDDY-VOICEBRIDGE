function renderNavbar(currentTab, progressData) {
  const t = (k) => window.LangManager.t(k);
  const currentLang = window.LangManager.getLang();

  const streak = progressData?.user?.streak || 3;
  const completed = progressData?.today?.completedWords || 0;
  const goal = progressData?.today?.dailyGoal || 5;

  return `
    <header class="bg-white/95 backdrop-blur-md border-b border-slate-200 sticky top-0 z-40 transition-all shadow-sm">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16">
          
          <!-- Logo & Brand -->
          <div class="flex items-center gap-3 cursor-pointer" onclick="window.switchTab('dashboard')">
            <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-sky-400 flex items-center justify-center text-white shadow-md shadow-indigo-200">
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 100-6 3 3 0 000 6z" />
              </svg>
            </div>
            <div>
              <div class="flex items-center gap-2">
                <span class="font-bold text-xl tracking-tight bg-gradient-to-r from-indigo-700 to-sky-600 bg-clip-text text-transparent">BhashaBuddy</span>
                <span class="text-xs bg-indigo-50 text-indigo-700 font-semibold px-2 py-0.5 rounded-full border border-indigo-200/60 hidden sm:inline-block">VoiceBridge Jam</span>
              </div>
              <p class="text-[10px] text-slate-500 hidden md:block">Bilingual Technical English for Engineering</p>
            </div>
          </div>

          <!-- Navigation Links -->
          <nav class="hidden lg:flex items-center gap-1">
            <button onclick="window.switchTab('dashboard')" class="px-3 py-2 rounded-lg text-sm font-medium transition-colors ${currentTab === 'dashboard' ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'}">
              ${t('navDashboard')}
            </button>
            <button onclick="window.switchTab('flashcards')" class="px-3 py-2 rounded-lg text-sm font-medium transition-colors ${currentTab === 'flashcards' ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'}">
              ${t('navFlashcards')}
            </button>
            <button onclick="window.switchTab('pronunciation')" class="px-3 py-2 rounded-lg text-sm font-medium transition-colors ${currentTab === 'pronunciation' ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'}">
              <span class="flex items-center gap-1.5">
                <span class="relative flex h-2 w-2">
                  <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                ${t('navPronunciation')}
              </span>
            </button>
            <button onclick="window.switchTab('vocabulary')" class="px-3 py-2 rounded-lg text-sm font-medium transition-colors ${currentTab === 'vocabulary' ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'}">
              ${t('navVocabulary')}
            </button>
            <button onclick="window.switchTab('quiz')" class="px-3 py-2 rounded-lg text-sm font-medium transition-colors ${currentTab === 'quiz' ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'}">
              ${t('navQuiz')}
            </button>
            <button onclick="window.switchTab('visualDict')" class="px-3 py-2 rounded-lg text-sm font-medium transition-colors ${currentTab === 'visualDict' ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'}">
              ${t('navVisualDict')}
            </button>
            <button onclick="window.switchTab('analytics')" class="px-3 py-2 rounded-lg text-sm font-medium transition-colors ${currentTab === 'analytics' ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'}">
              ${t('navAnalytics')}
            </button>
            <button onclick="window.switchTab('chatbot')" class="px-3 py-2 rounded-lg text-sm font-medium transition-colors ${currentTab === 'chatbot' ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'}">
              ${t('navChatbot')}
            </button>
          </nav>

          <!-- Right: Streak, Goal, Language Picker -->
          <div class="flex items-center gap-3">
            
            <!-- Streak Counter -->
            <div class="flex items-center gap-1 bg-amber-50 text-amber-800 border border-amber-200/80 px-2.5 py-1 rounded-full text-xs font-bold" title="Daily Learning Streak">
              <span>🔥</span>
              <span>${streak}</span>
              <span class="hidden sm:inline font-medium text-amber-700">Days</span>
            </div>

            <!-- Daily Target Pill -->
            <div class="hidden sm:flex items-center gap-1.5 bg-emerald-50 text-emerald-800 border border-emerald-200/80 px-2.5 py-1 rounded-full text-xs font-semibold" title="Daily Goal Progress">
              <span>🎯</span>
              <span>${completed}/${goal}</span>
            </div>

            <!-- Language Switcher Dropdown -->
            <div class="relative">
              <select 
                id="languageSelect"
                onchange="window.handleLanguageChange(this.value)"
                class="bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs sm:text-sm font-semibold rounded-lg px-2.5 py-1.5 pr-7 border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer appearance-none transition-all shadow-sm"
              >
                <option value="te" ${currentLang === 'te' ? 'selected' : ''}>🇮🇳 తెలుగు (Telugu)</option>
                <option value="hi" ${currentLang === 'hi' ? 'selected' : ''}>🇮🇳 हिन्दी (Hindi)</option>
                <option value="ta" ${currentLang === 'ta' ? 'selected' : ''}>🇮🇳 தமிழ் (Tamil)</option>
                <option value="en" ${currentLang === 'en' ? 'selected' : ''}>🌐 English</option>
              </select>
              <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-500">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </div>

          </div>
        </div>

        <!-- Mobile Navigation Strip -->
        <div class="flex lg:hidden overflow-x-auto py-2 gap-1 border-t border-slate-100 no-scrollbar">
          <button onclick="window.switchTab('dashboard')" class="px-2.5 py-1 text-xs whitespace-nowrap rounded-md ${currentTab === 'dashboard' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-600 hover:bg-slate-100'}">${t('navDashboard')}</button>
          <button onclick="window.switchTab('flashcards')" class="px-2.5 py-1 text-xs whitespace-nowrap rounded-md ${currentTab === 'flashcards' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-600 hover:bg-slate-100'}">${t('navFlashcards')}</button>
          <button onclick="window.switchTab('pronunciation')" class="px-2.5 py-1 text-xs whitespace-nowrap rounded-md ${currentTab === 'pronunciation' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-600 hover:bg-slate-100'}">🎙️ ${t('navPronunciation')}</button>
          <button onclick="window.switchTab('vocabulary')" class="px-2.5 py-1 text-xs whitespace-nowrap rounded-md ${currentTab === 'vocabulary' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-600 hover:bg-slate-100'}">${t('navVocabulary')}</button>
          <button onclick="window.switchTab('quiz')" class="px-2.5 py-1 text-xs whitespace-nowrap rounded-md ${currentTab === 'quiz' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-600 hover:bg-slate-100'}">${t('navQuiz')}</button>
          <button onclick="window.switchTab('visualDict')" class="px-2.5 py-1 text-xs whitespace-nowrap rounded-md ${currentTab === 'visualDict' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-600 hover:bg-slate-100'}">${t('navVisualDict')}</button>
          <button onclick="window.switchTab('analytics')" class="px-2.5 py-1 text-xs whitespace-nowrap rounded-md ${currentTab === 'analytics' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-600 hover:bg-slate-100'}">📊 ${t('navAnalytics')}</button>
          <button onclick="window.switchTab('chatbot')" class="px-2.5 py-1 text-xs whitespace-nowrap rounded-md ${currentTab === 'chatbot' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-600 hover:bg-slate-100'}">${t('navChatbot')}</button>
        </div>

      </div>
    </header>
  `;
}

window.renderNavbar = renderNavbar;
