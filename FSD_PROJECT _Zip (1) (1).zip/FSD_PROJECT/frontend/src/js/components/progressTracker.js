function renderProgressTracker(state) {
  const t = (k) => window.LangManager.t(k);
  const lang = window.LangManager.getLang();
  const progress = state.progress || {};
  const today = progress.today || { completedWords: 3, dailyGoal: 5, percentage: 60 };
  const stats = progress.stats || { totalAttempts: 12, averageScore: 88, masteredWords: 15, totalVocabInDeck: 51 };
  const recentAttempts = progress.recentAttempts || [];

  const domains = [
    { name: "Computer Fundamentals", count: 8, mastered: Math.min(8, Math.round(stats.masteredWords * 0.25)) },
    { name: "Programming Languages", count: 9, mastered: Math.min(9, Math.round(stats.masteredWords * 0.25)) },
    { name: "Data Structures", count: 8, mastered: Math.min(8, Math.round(stats.masteredWords * 0.2)) },
    { name: "Database Systems", count: 8, mastered: Math.min(8, Math.round(stats.masteredWords * 0.15)) },
    { name: "Computer Networks", count: 8, mastered: Math.min(8, Math.round(stats.masteredWords * 0.15)) },
    { name: "Artificial Intelligence", count: 6, mastered: Math.min(6, Math.round(stats.masteredWords * 0.1)) },
    { name: "Engineering Mathematics", count: 4, mastered: Math.min(4, Math.round(stats.masteredWords * 0.1)) }
  ];

  return `
    <div class="max-w-4xl mx-auto space-y-6 animate-fadeIn">
      
      <!-- Header -->
      <div class="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white p-6 rounded-3xl shadow-lg border border-emerald-500/20">
        <div class="flex items-center justify-between">
          <div>
            <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-200 text-xs font-semibold mb-2">
              <span>📊</span>
              <span>Learning Analytics & Goal Tracker</span>
            </div>
            <h1 class="text-2xl font-black text-white">My Learning Trajectory</h1>
            <p class="text-xs text-emerald-200/90 mt-1">Track your daily 5-word milestones, speech accuracy evolution, and vocabulary mastery across all engineering modules.</p>
          </div>
        </div>
      </div>

      <!-- Top Metric Cards Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        <!-- Circular Progress Goal Ring -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div class="relative w-20 h-20 shrink-0">
            <svg class="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
              <path
                class="text-slate-100"
                stroke-width="3.5"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                class="text-emerald-500 transition-all duration-1000 ease-out"
                stroke-dasharray="${today.percentage}, 100"
                stroke-linecap="round"
                stroke-width="3.5"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <div class="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span class="text-xs font-bold text-slate-900">${today.percentage}%</span>
            </div>
          </div>

          <div>
            <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400">Today's Target</span>
            <h3 class="text-xl font-black text-slate-900 mt-0.5">${today.completedWords} / ${today.dailyGoal}</h3>
            <p class="text-xs text-emerald-600 font-semibold mt-0.5">
              ${today.completedWords >= today.dailyGoal ? '🎉 Daily Goal Met!' : `${today.dailyGoal - today.completedWords} words remaining`}
            </p>
          </div>
        </div>

        <!-- 7-Day Active Streak -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div class="flex items-center justify-between">
            <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400">Continuous Streak</span>
            <span class="text-xl">🔥</span>
          </div>
          <div>
            <h3 class="text-3xl font-black text-amber-600">${progress.user?.streak || 3} <span class="text-sm font-bold text-slate-600">Days</span></h3>
            <p class="text-xs text-slate-500 mt-1">Practice tomorrow to reach 4 days!</p>
          </div>
        </div>

        <!-- Speech Accuracy -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div class="flex items-center justify-between">
            <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400">Mean Pronunciation</span>
            <span class="text-xl">🎙️</span>
          </div>
          <div>
            <h3 class="text-3xl font-black text-indigo-600">${stats.averageScore || 88}%</h3>
            <p class="text-xs text-slate-500 mt-1">Across ${stats.totalAttempts || 0} voice attempts</p>
          </div>
        </div>

      </div>

      <!-- Domain Mastery Progress Bars -->
      <div class="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
        <div>
          <h2 class="text-base font-bold text-slate-900">Engineering Domain Mastery</h2>
          <p class="text-xs text-slate-500">Curriculum progression across all 7 technical disciplines.</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          ${domains.map(dom => {
            const pct = Math.min(100, Math.round((dom.mastered / dom.count) * 100));
            return `
              <div class="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5">
                <div class="flex items-center justify-between text-xs font-bold text-slate-800">
                  <span>${dom.name}</span>
                  <span class="text-indigo-600">${dom.mastered} / ${dom.count}</span>
                </div>
                <div class="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                  <div class="bg-indigo-600 h-2 rounded-full transition-all duration-700" style="width: ${pct}%"></div>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>

      <!-- Recent Practice History from SQLite -->
      <div class="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
        <div class="flex items-center justify-between">
          <div>
            <h2 class="text-base font-bold text-slate-900">Recent Pronunciation Evaluations (SQLite Log)</h2>
            <p class="text-xs text-slate-500">Persistent log of student voice attempts with similarity metrics.</p>
          </div>
          <button onclick="window.fetchProgress()" class="text-xs text-indigo-600 hover:text-indigo-800 font-semibold">
            🔄 Refresh Log
          </button>
        </div>

        ${recentAttempts.length > 0 ? `
          <div class="overflow-x-auto">
            <table class="w-full text-xs text-left">
              <thead class="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                <tr>
                  <th class="p-3">Target Word</th>
                  <th class="p-3">Spoken Transcript</th>
                  <th class="p-3">Score</th>
                  <th class="p-3">Feedback</th>
                  <th class="p-3">Attempt Date</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                ${recentAttempts.map(att => `
                  <tr class="hover:bg-slate-50/50">
                    <td class="p-3 font-bold text-slate-900">${att.target_word}</td>
                    <td class="p-3 font-mono text-indigo-700">${att.recognized_text || '—'}</td>
                    <td class="p-3 font-bold ${att.match_score >= 90 ? 'text-emerald-600' : att.match_score >= 75 ? 'text-indigo-600' : 'text-amber-600'}">
                      ${att.match_score}%
                    </td>
                    <td class="p-3 text-slate-600 max-w-xs truncate">${att.feedback}</td>
                    <td class="p-3 text-slate-400 font-mono">${att.attempt_date ? att.attempt_date.split('T')[0] : 'Today'}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        ` : `
          <div class="p-6 text-center text-slate-400 text-xs italic bg-slate-50 rounded-xl">
            No voice attempts logged yet. Try speaking a word in the Voice Lab!
          </div>
        `}
      </div>

    </div>
  `;
}

window.renderProgressTracker = renderProgressTracker;
