let activeWordIndex = 0;
let isRecording = false;
let latestEvaluation = null;
let recordingStatusText = "";
let selectedPlaybackSpeed = 1.0;

// Peer recordings simulation (FSD Stretch Feature)
const peerRecordings = [
  { student: "Student A (Warangal, TS)", score: 96, date: "10 mins ago", votes: 14 },
  { student: "Student B (Vijayawada, AP)", score: 92, date: "25 mins ago", votes: 9 },
  { student: "Student C (Patna, BR)", score: 88, date: "1 hour ago", votes: 7 }
];

function renderPronunciationLab(state) {
  const t = (k) => window.LangManager.t(k);
  const lang = window.LangManager.getLang();
  const words = state.vocabularyList || [];

  if (words.length === 0) {
    return `<div class="p-8 text-center text-slate-500">Loading words for Voice Lab...</div>`;
  }

  if (activeWordIndex >= words.length) activeWordIndex = 0;
  const currentWord = words[activeWordIndex];

  let regionalMeaning = currentWord.telugu_meaning;
  if (lang === 'hi') regionalMeaning = currentWord.hindi_meaning;
  if (lang === 'ta') regionalMeaning = currentWord.tamil_meaning;

  // Syllable breakdown generator
  const syllables = currentWord.phonetic_guide
    .replace(/[\[\]]/g, '')
    .split('-')
    .map(s => s.trim());

  return `
    <div class="max-w-4xl mx-auto space-y-6 animate-fadeIn">
      
      <!-- Studio Header -->
      <div class="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-3xl shadow-xl border border-indigo-500/20">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold mb-2">
              <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span>VoiceBridge Speech AI Studio</span>
            </div>
            <h1 class="text-2xl sm:text-3xl font-black text-white">Pronunciation & Voice Lab</h1>
            <p class="text-xs text-indigo-200/80 mt-1">Practice native syllable stress, record your spoken English, and receive instant phonetic Levenshtein scoring with regional accent tolerance.</p>
          </div>

          <!-- Quick Word Picker -->
          <div class="sm:text-right">
            <label class="block text-[11px] uppercase tracking-wider text-indigo-300 font-bold mb-1">Select Word:</label>
            <select 
              id="voiceLabWordSelect"
              onchange="window.selectVoiceLabWord(this.value)" 
              class="bg-white/10 hover:bg-white/20 text-white text-xs font-semibold rounded-xl px-3 py-2 border border-white/20 focus:outline-none focus:ring-2 focus:ring-indigo-400 cursor-pointer"
            >
              ${words.map((w, idx) => `
                <option value="${idx}" class="text-slate-900" ${idx === activeWordIndex ? 'selected' : ''}>
                  ${w.english_word} (${w.category})
                </option>
              `).join('')}
            </select>
          </div>
        </div>
      </div>

      <!-- Main Speech Practice Arena -->
      <div class="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-8">
        
        <!-- Target Word Display -->
        <div class="text-center space-y-3">
          <div class="inline-flex items-center gap-2">
            <span class="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full bg-indigo-50 text-indigo-700">
              ${currentWord.category} • ${currentWord.difficulty}
            </span>
          </div>

          <h2 class="text-4xl sm:text-6xl font-black text-slate-900 tracking-tight">
            ${currentWord.english_word}
          </h2>

          <!-- Syllable breakdown chips -->
          <div class="flex items-center justify-center gap-2 pt-1 flex-wrap">
            <span class="text-xs font-semibold text-slate-400 mr-1">Syllables:</span>
            ${syllables.map((syl, i) => `
              <span class="px-3 py-1 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 rounded-lg text-slate-800 font-mono font-bold text-sm border border-slate-200 transition-colors cursor-pointer" title="Syllable ${i+1}">
                ${syl}
              </span>
            `).join('<span class="text-slate-300">•</span>')}
          </div>
          
          <div class="pt-2 max-w-xl mx-auto">
            <p class="text-xs sm:text-sm text-slate-600 font-medium">
              ${regionalMeaning}
            </p>
          </div>
        </div>

        <!-- Audio Speed Control & Listen Actions -->
        <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200 max-w-xl mx-auto space-y-3">
          <div class="flex items-center justify-between text-xs font-semibold text-slate-600">
            <span>🔊 Native English Text-to-Speech:</span>
            <div class="flex items-center gap-1.5">
              <span class="text-[11px] text-slate-400">Speed:</span>
              ${[0.75, 1.0, 1.25].map(spd => `
                <button 
                  onclick="window.setPlaybackSpeed(${spd})" 
                  class="px-2 py-0.5 rounded text-[11px] font-bold ${selectedPlaybackSpeed === spd ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'}"
                >
                  ${spd}x
                </button>
              `).join('')}
            </div>
          </div>

          <div class="flex items-center justify-center gap-3">
            <button 
              onclick="window.SpeechService.speak('${currentWord.english_word.replace(/'/g, "\\'")}', ${selectedPlaybackSpeed})" 
              class="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-2 transition-all shadow-md shadow-indigo-200"
            >
              🔊 Speak Word (${selectedPlaybackSpeed}x)
            </button>
            <button 
              onclick="window.SpeechService.speak('${currentWord.example_sentence.replace(/'/g, "\\'")}', ${selectedPlaybackSpeed})" 
              class="px-4 py-2.5 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-semibold text-xs flex items-center gap-1.5 transition-colors"
            >
              📖 Listen Example Sentence
            </button>
          </div>
        </div>

        <!-- Big Microphone Speaking Hub -->
        <div class="text-center space-y-4 pt-2 border-t border-slate-100">
          
          <div class="relative inline-block">
            <!-- Pulsing ring when recording -->
            ${isRecording ? `
              <div class="absolute -inset-5 rounded-full bg-rose-500/20 animate-ping"></div>
              <div class="absolute -inset-3 rounded-full bg-rose-500/30 animate-pulse"></div>
            ` : ''}

            <button 
              id="micButton"
              onclick="window.toggleMicrophoneRecording()" 
              class="relative w-28 h-28 rounded-full flex flex-col items-center justify-center text-white shadow-xl transition-all transform active:scale-95 ${
                isRecording 
                  ? 'bg-gradient-to-tr from-rose-600 to-rose-500 shadow-rose-300 ring-4 ring-rose-200' 
                  : 'bg-gradient-to-tr from-indigo-600 via-indigo-500 to-sky-500 hover:shadow-indigo-300'
              }"
            >
              ${isRecording ? `
                <div class="flex items-center gap-1 h-6 mb-1">
                  <div class="w-1 bg-white animate-pulse h-4 rounded"></div>
                  <div class="w-1 bg-white animate-pulse h-6 rounded"></div>
                  <div class="w-1 bg-white animate-pulse h-3 rounded"></div>
                  <div class="w-1 bg-white animate-pulse h-5 rounded"></div>
                </div>
                <span class="text-[10px] font-black uppercase tracking-wider">Listening</span>
              ` : `
                <svg class="w-9 h-9" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 100-6 3 3 0 000 6z" />
                </svg>
                <span class="text-[10px] font-black mt-1 uppercase tracking-wider">Tap to Speak</span>
              `}
            </button>
          </div>

          <p class="text-xs font-semibold ${isRecording ? 'text-rose-600 animate-pulse' : 'text-slate-500'}">
            ${recordingStatusText || "Click microphone, speak the target word, and verify your pronunciation."}
          </p>

          <!-- Playback My Recorded Voice Button -->
          ${window.SpeechService.lastRecordedAudioUrl ? `
            <div class="pt-2 animate-fadeIn">
              <button 
                onclick="window.SpeechService.playRecordedVoice()" 
                class="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold border border-slate-300 shadow-sm transition-all"
              >
                <span>▶️</span>
                <span>Play Back My Recorded Voice</span>
              </button>
            </div>
          ` : ''}

          <!-- Fallback Manual Text Input Simulator -->
          <div class="pt-2">
            <details class="text-left max-w-md mx-auto">
              <summary class="text-xs text-indigo-600 font-medium cursor-pointer text-center hover:underline">
                ⌨️ Browser has no microphone or permission? Test evaluation manually
              </summary>
              <div class="mt-3 p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center gap-2">
                <input 
                  type="text" 
                  id="manualPronounceInput" 
                  placeholder="Type word (e.g. Algorithm or Algorith)" 
                  class="flex-1 text-xs px-3 py-2 bg-white rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
                <button 
                  onclick="window.testManualPronunciation()" 
                  class="px-3 py-2 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 transition-colors"
                >
                  Score Test
                </button>
              </div>
            </details>
          </div>

        </div>

        <!-- Evaluation Results Card -->
        ${latestEvaluation ? `
          <div class="bg-gradient-to-b from-slate-50 to-indigo-50/40 rounded-3xl p-6 sm:p-8 border-2 ${
            latestEvaluation.matchScore >= 90 ? 'border-emerald-400 bg-emerald-50/20' :
            latestEvaluation.matchScore >= 75 ? 'border-indigo-300' : 'border-amber-300'
          } space-y-5 animate-scaleUp">
            
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200/60 pb-4">
              <div>
                <span class="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">Levenshtein Evaluation Result</span>
                <h3 class="text-xl font-black text-slate-900 mt-0.5">
                  ${latestEvaluation.matchScore >= 90 ? '🎉 Outstanding Pronunciation!' :
                    latestEvaluation.matchScore >= 75 ? '👍 Very Good Pronunciation!' :
                    '🔄 Keep Practicing Syllables'}
                </h3>
              </div>

              <!-- Score Gauge -->
              <div class="flex items-center gap-3">
                <div class="text-right">
                  <div class="text-4xl font-black ${
                    latestEvaluation.matchScore >= 90 ? 'text-emerald-600' :
                    latestEvaluation.matchScore >= 75 ? 'text-indigo-600' : 'text-amber-600'
                  }">
                    ${latestEvaluation.matchScore}%
                  </div>
                  <p class="text-[10px] text-slate-500 font-bold uppercase">Similarity Score</p>
                </div>

                <div class="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl font-black ${
                  latestEvaluation.matchScore >= 90 ? 'bg-emerald-100 text-emerald-700' :
                  latestEvaluation.matchScore >= 75 ? 'bg-indigo-100 text-indigo-700' : 'bg-amber-100 text-amber-700'
                }">
                  ${latestEvaluation.matchScore >= 90 ? 'A+' : latestEvaluation.matchScore >= 75 ? 'B+' : 'C'}
                </div>
              </div>
            </div>

            <!-- Comparison Breakdown -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div class="bg-white p-4 rounded-xl border border-slate-200">
                <span class="text-slate-400 font-semibold block mb-0.5">Target English Word:</span>
                <span class="font-bold text-slate-900 text-base font-mono">${latestEvaluation.targetWord}</span>
              </div>
              <div class="bg-white p-4 rounded-xl border border-slate-200">
                <span class="text-slate-400 font-semibold block mb-0.5">Recognized Spoken Speech:</span>
                <span class="font-bold text-indigo-700 text-base font-mono">${latestEvaluation.spokenText}</span>
              </div>
            </div>

            ${latestEvaluation.accentToleranceApplied ? `
              <div class="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center gap-2">
                <span class="text-base">🛡️</span>
                <span><b>FSD Accent Tolerance Applied:</b> Regional accent variation detected within acceptable tolerance ($\le 2$ edit distance).</span>
              </div>
            ` : ''}

            <!-- Feedback prose -->
            <p class="text-xs sm:text-sm text-slate-700 leading-relaxed font-medium bg-white p-4 rounded-xl border border-slate-200">
              💡 ${latestEvaluation.feedback}
            </p>

            <!-- Vernacular Guidance Tip -->
            <div class="p-4 rounded-xl bg-indigo-50 border border-indigo-200 text-xs text-indigo-900">
              <b>Regional Speaker Pronunciation Tip (${lang.toUpperCase()}):</b>
              <p class="mt-1 text-slate-700 leading-relaxed">
                ${
                  lang === 'te' ? "తెలుగు మాట్లాడే విద్యార్థులు ఆంగ్ల పదాల చివర 'ఉ' కారాన్ని (ఉదా: 'కంప్యూటరు', 'అల్గారిథము') కలపకుండా, పదాన్ని మృదువుగా ముగించాలి. సిలబుల్స్ పై సరైన స్ట్రెస్ ఇవ్వాలి." :
                  lang === 'hi' ? "हिंदी भाषी छात्र ध्यान दें: शब्दों के अंतिम व्यंजन को स्पष्ट रूप से समाप्त करें और सही सिलेबल (शब्दांश) पर जोर दें।" :
                  "உச்சரிப்பின் போது ஒவ்வொரு எழுத்துத் தொகுதியையும் (Syllables) நிதானமாகவும் தெளிவாகவும் பேசவும்."
                }
              </p>
            </div>

            <!-- Action buttons -->
            <div class="flex items-center justify-between pt-2">
              ${window.SpeechService.lastRecordedAudioUrl ? `
                <button 
                  onclick="window.SpeechService.playRecordedVoice()" 
                  class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-all"
                >
                  ▶️ Replay Spoken Audio
                </button>
              ` : '<div></div>'}

              <button 
                onclick="window.markLearned(${currentWord.word_id})" 
                class="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-emerald-200"
              >
                ✓ Mark Mastered & Save to SQLite
              </button>
            </div>

          </div>
        ` : ''}

        <!-- Peer Pronunciation Challenge Simulator (FSD Stretch Feature) -->
        <div class="p-5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-3">
          <div class="flex items-center justify-between">
            <span class="font-bold text-slate-900 flex items-center gap-1.5">
              <span>👥</span>
              <span>Peer Pronunciation Challenge (Anonymous Classmate Audio)</span>
            </span>
            <span class="text-[10px] bg-indigo-100 text-indigo-800 font-bold px-2 py-0.5 rounded-full">Community</span>
          </div>
          <p class="text-slate-500">Listen to how classmates from regional-medium schools pronounce "${currentWord.english_word}":</p>

          <div class="space-y-2">
            ${peerRecordings.map((peer, i) => `
              <div class="p-3 bg-white rounded-xl border border-slate-200 flex items-center justify-between">
                <div>
                  <span class="font-bold text-slate-800">${peer.student}</span>
                  <span class="text-slate-400 ml-2">• ${peer.date}</span>
                  <div class="text-[11px] font-semibold text-emerald-600 mt-0.5">Score: ${peer.score}%</div>
                </div>
                <div class="flex items-center gap-2">
                  <button 
                    onclick="window.SpeechService.speak('${currentWord.english_word.replace(/'/g, "\\'")}', 0.9)" 
                    class="px-3 py-1 bg-slate-100 hover:bg-indigo-50 text-indigo-700 rounded-lg font-bold text-xs"
                  >
                    ▶️ Listen
                  </button>
                  <button 
                    onclick="window.upvotePeer(${i})" 
                    class="px-2.5 py-1 bg-slate-100 hover:bg-amber-50 text-amber-700 rounded-lg text-xs"
                    title="Upvote Recording"
                  >
                    👍 ${peer.votes}
                  </button>
                </div>
              </div>
            `).join('')}
          </div>
        </div>

      </div>

    </div>
  `;
}

window.renderPronunciationLab = renderPronunciationLab;

window.setPlaybackSpeed = (speed) => {
  selectedPlaybackSpeed = speed;
  window.renderApp();
};

window.upvotePeer = (idx) => {
  if (peerRecordings[idx]) {
    peerRecordings[idx].votes++;
    window.renderApp();
  }
};

window.selectVoiceLabWord = (idx) => {
  activeWordIndex = parseInt(idx, 10);
  latestEvaluation = null;
  recordingStatusText = "";
  window.renderApp();
};

window.openVoiceLabForWord = (wordName, wordId) => {
  const words = window.appState?.vocabularyList || [];
  const foundIdx = words.findIndex(w => w.english_word.toLowerCase() === wordName.toLowerCase());
  if (foundIdx !== -1) {
    activeWordIndex = foundIdx;
  }
  latestEvaluation = null;
  recordingStatusText = "";
  window.switchTab('pronunciation');
};

window.toggleMicrophoneRecording = () => {
  const words = window.appState?.vocabularyList || [];
  const currentWord = words[activeWordIndex] || { english_word: 'Algorithm' };

  if (isRecording) {
    window.SpeechService.stopListening();
    isRecording = false;
    recordingStatusText = "Stopped listening.";
    window.renderApp();
    return;
  }

  recordingStatusText = "🎙️ Listening... Speak the word '" + currentWord.english_word + "' clearly!";
  isRecording = true;
  window.renderApp();

  window.SpeechService.startListening({
    onStart: () => {
      isRecording = true;
      recordingStatusText = "🎙️ Microphone active: Speak the word '" + currentWord.english_word + "'...";
      window.renderApp();
    },
    onResult: (spokenText) => {
      isRecording = false;
      recordingStatusText = `Recognized: "${spokenText}". Evaluating with Levenshtein algorithm...`;
      window.renderApp();

      window.API.evaluatePronunciation(currentWord.english_word, spokenText, currentWord.word_id)
        .then(res => {
          if (res.success) {
            latestEvaluation = res.data;
            recordingStatusText = `Score: ${res.data.matchScore}%`;
            if (res.data.matchScore >= 90 && window.triggerCelebration) {
              window.triggerCelebration();
            }
          }
          window.renderApp();
        })
        .catch(err => {
          console.error(err);
          const local = window.computeLevenshtein(currentWord.english_word, spokenText);
          latestEvaluation = {
            targetWord: currentWord.english_word,
            spokenText: spokenText,
            matchScore: local.score,
            distance: local.distance,
            accentToleranceApplied: local.accentTolerance,
            feedback: local.score >= 85 ? "Excellent pronunciation!" : "Good try! Practice with native TTS."
          };
          window.renderApp();
        });
    },
    onError: (err) => {
      isRecording = false;
      recordingStatusText = `Microphone notice: ${err.error || 'Speech ended'}. Try again or use manual simulator.`;
      window.renderApp();
    },
    onEnd: () => {
      isRecording = false;
      window.renderApp();
    }
  });
};

window.testManualPronunciation = () => {
  const input = document.getElementById('manualPronounceInput');
  if (!input || !input.value.trim()) return;

  const words = window.appState?.vocabularyList || [];
  const currentWord = words[activeWordIndex] || { english_word: 'Algorithm' };
  const spokenText = input.value.trim();

  window.API.evaluatePronunciation(currentWord.english_word, spokenText, currentWord.word_id)
    .then(res => {
      if (res.success) {
        latestEvaluation = res.data;
        if (res.data.matchScore >= 90 && window.triggerCelebration) {
          window.triggerCelebration();
        }
      }
      window.renderApp();
    })
    .catch(err => {
      const local = window.computeLevenshtein(currentWord.english_word, spokenText);
      latestEvaluation = {
        targetWord: currentWord.english_word,
        spokenText: spokenText,
        matchScore: local.score,
        distance: local.distance,
        accentToleranceApplied: local.accentTolerance,
        feedback: local.score >= 85 ? "Excellent pronunciation!" : "Practice more with audio."
      };
      window.renderApp();
    });
};
