let quizQuestions = [];
let currentQuestionIndex = 0;
let userAnswers = {};
let quizCompleted = false;
let quizScore = 0;
let quizTimerSeconds = 30;
let timerInterval = null;

function renderQuiz(state) {
  const t = (k) => window.LangManager.t(k);
  const lang = window.LangManager.getLang();

  // Landing view when no active quiz
  if (quizQuestions.length === 0) {
    return `
      <div class="max-w-xl mx-auto bg-white rounded-3xl p-8 border border-slate-200 text-center shadow-lg space-y-6 animate-fadeIn">
        <div class="w-20 h-20 rounded-2xl bg-gradient-to-tr from-indigo-600 to-sky-500 text-white mx-auto flex items-center justify-center text-3xl shadow-md shadow-indigo-200">
          📝
        </div>
        <div>
          <span class="text-xs font-bold uppercase tracking-wider text-indigo-600">Daily Assessment</span>
          <h2 class="text-2xl font-black text-slate-900 mt-1">${t('quizTitle')}</h2>
          <p class="text-xs sm:text-sm text-slate-600 max-w-md mx-auto mt-2 leading-relaxed">
            Test your understanding with 5 dynamic bilingual questions. Questions test both English-to-Vernacular recognition and technical engineering context.
          </p>
        </div>

        <!-- Quiz features pills -->
        <div class="flex items-center justify-center gap-2 flex-wrap text-xs text-slate-600 font-semibold">
          <span class="px-3 py-1 bg-slate-100 rounded-full">5 Questions</span>
          <span class="px-3 py-1 bg-slate-100 rounded-full">Instant Vernacular Feedback</span>
          <span class="px-3 py-1 bg-slate-100 rounded-full">Streak Bonus</span>
        </div>

        <button 
          onclick="window.startNewQuiz()" 
          class="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm shadow-lg shadow-indigo-200 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
        >
          🚀 Start Today's Quiz
        </button>
      </div>
    `;
  }

  // Quiz Finished Results
  if (quizCompleted) {
    const percentage = Math.round((quizScore / quizQuestions.length) * 100);
    return `
      <div class="max-w-xl mx-auto bg-white rounded-3xl p-8 border border-slate-200 text-center shadow-xl space-y-6 animate-scaleUp">
        <div class="w-20 h-20 rounded-full mx-auto flex items-center justify-center text-4xl shadow-md ${
          percentage >= 80 ? 'bg-emerald-100 text-emerald-700 shadow-emerald-200' : 'bg-indigo-100 text-indigo-700 shadow-indigo-200'
        }">
          ${percentage >= 80 ? '🏆' : '🎯'}
        </div>

        <div>
          <span class="text-xs font-bold uppercase tracking-wider text-slate-400">Quiz Completed</span>
          <h2 class="text-3xl font-black text-slate-900 mt-1">Your Score: ${quizScore} / ${quizQuestions.length}</h2>
          <p class="text-sm font-bold mt-1.5 ${percentage >= 80 ? 'text-emerald-600' : 'text-indigo-600'}">
            ${percentage}% Accuracy • Daily Learning Progress Updated in SQLite!
          </p>
        </div>

        <!-- Detailed Review List -->
        <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-600 space-y-3 text-left max-h-64 overflow-y-auto">
          <p class="font-bold text-slate-900 border-b border-slate-200 pb-1">Question Review:</p>
          ${quizQuestions.map((q, idx) => `
            <div class="py-1.5 border-b border-slate-200/60 last:border-0 space-y-1">
              <div class="flex items-center justify-between">
                <span class="font-bold text-slate-800">${idx + 1}. ${q.targetWord || 'Term'}</span>
                <span class="${userAnswers[idx] === q.correctAnswer ? 'text-emerald-600 font-bold' : 'text-rose-600 font-bold'}">
                  ${userAnswers[idx] === q.correctAnswer ? '✓ Correct' : '✗ Incorrect'}
                </span>
              </div>
              <p class="text-[11px] text-slate-500 italic">Correct: "${q.correctAnswer}"</p>
            </div>
          `).join('')}
        </div>

        <div class="flex flex-col sm:flex-row items-center justify-center gap-3">
          <button 
            onclick="window.startNewQuiz()" 
            class="w-full sm:w-auto px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition-all"
          >
            🔄 Take Another Quiz
          </button>
          <button 
            onclick="window.switchTab('flashcards')" 
            class="w-full sm:w-auto px-5 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs transition-colors"
          >
            Review Flashcards
          </button>
        </div>
      </div>
    `;
  }

  // Active Question View
  const q = quizQuestions[currentQuestionIndex];
  const selectedAnswer = userAnswers[currentQuestionIndex];
  const isAnswered = selectedAnswer !== undefined;

  return `
    <div class="max-w-2xl mx-auto space-y-5 animate-fadeIn">
      
      <!-- Quiz Progress Header -->
      <div class="flex items-center justify-between">
        <div>
          <span class="text-xs font-bold uppercase tracking-wider text-indigo-600 font-mono">Question ${currentQuestionIndex + 1} of ${quizQuestions.length}</span>
          <h2 class="text-xl font-black text-slate-900">${t('quizTitle')}</h2>
        </div>
        <div class="flex items-center gap-2">
          <div class="text-xs font-mono font-bold text-slate-700 bg-slate-100 px-3 py-1 rounded-full border border-slate-200">
            Score: ${quizScore}
          </div>
          <button 
            onclick="window.SpeechService.speak('${(q.targetWord || q.questionText).replace(/'/g, "\\'")}')" 
            class="p-2 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200"
            title="Read Question Aloud"
          >
            🔊
          </button>
        </div>
      </div>

      <div class="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
        <div class="bg-indigo-600 h-2 rounded-full transition-all duration-300" style="width: ${((currentQuestionIndex + 1) / quizQuestions.length) * 100}%"></div>
      </div>

      <!-- Question Card -->
      <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        
        <div class="space-y-1.5">
          <h3 class="text-lg sm:text-xl font-black text-slate-900">
            ${q.questionText}
          </h3>
          ${q.questionSub ? `
            <div class="inline-flex items-center gap-2 bg-indigo-50 text-indigo-900 px-3 py-1 rounded-lg text-xs font-semibold border border-indigo-100">
              <span>💡</span>
              <span>${q.questionSub}</span>
            </div>
          ` : ''}
        </div>

        <!-- Options Grid -->
        <div class="space-y-3">
          ${q.options.map((opt, idx) => {
            let btnClass = "border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/40 text-slate-800 bg-white";
            if (isAnswered) {
              if (opt === q.correctAnswer) {
                btnClass = "border-emerald-500 bg-emerald-50 text-emerald-900 font-bold ring-2 ring-emerald-400";
              } else if (opt === selectedAnswer) {
                btnClass = "border-rose-400 bg-rose-50 text-rose-800 line-through";
              } else {
                btnClass = "border-slate-100 opacity-40 text-slate-400 bg-slate-50";
              }
            }

            return `
              <button 
                onclick="window.selectQuizOption('${opt.replace(/'/g, "\\'")}')" 
                ${isAnswered ? 'disabled' : ''}
                class="w-full p-4 rounded-xl border text-left text-xs sm:text-sm transition-all flex items-center justify-between shadow-sm ${btnClass}"
              >
                <div class="flex items-center gap-3">
                  <span class="w-6 h-6 rounded-lg bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center shrink-0">
                    ${String.fromCharCode(65 + idx)}
                  </span>
                  <span>${opt}</span>
                </div>

                ${isAnswered && opt === q.correctAnswer ? `
                  <span class="text-emerald-600 font-bold text-xs shrink-0">✓ Correct</span>
                ` : ''}
              </button>
            `;
          }).join('')}
        </div>

        <!-- Explanation Drawer (after answering) -->
        ${isAnswered ? `
          <div class="p-4 rounded-2xl bg-indigo-50/80 border border-indigo-100 text-xs space-y-1.5 animate-fadeIn">
            <span class="font-bold text-indigo-900 block">Engineering Explanation:</span>
            <p class="text-slate-700 leading-relaxed">${q.explanation}</p>
            ${q.example ? `<p class="text-indigo-800 italic mt-1 font-medium">Context Example: "${q.example}"</p>` : ''}
          </div>
        ` : ''}

        <!-- Next / Finish Action -->
        <div class="flex items-center justify-between pt-2 border-t border-slate-100">
          <span class="text-xs text-slate-400 italic">
            ${isAnswered ? 'Review explanation above and proceed.' : 'Select an answer option to verify.'}
          </span>

          ${isAnswered ? `
            <button 
              onclick="window.nextQuizQuestion()" 
              class="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition-all"
            >
              ${currentQuestionIndex === quizQuestions.length - 1 ? 'Finish Quiz & Tally' : 'Next Question &rarr;'}
            </button>
          ` : ''}
        </div>

      </div>

    </div>
  `;
}

window.renderQuiz = renderQuiz;

window.startNewQuiz = () => {
  const lang = window.LangManager.getLang();
  window.API.getQuiz(lang).then(res => {
    if (res.success && res.data) {
      quizQuestions = res.data;
      currentQuestionIndex = 0;
      userAnswers = {};
      quizCompleted = false;
      quizScore = 0;
      window.renderApp();
    }
  });
};

window.selectQuizOption = (opt) => {
  if (userAnswers[currentQuestionIndex] !== undefined) return;
  userAnswers[currentQuestionIndex] = opt;
  const q = quizQuestions[currentQuestionIndex];
  if (opt === q.correctAnswer) {
    quizScore++;
  }
  window.renderApp();
};

window.nextQuizQuestion = () => {
  if (currentQuestionIndex < quizQuestions.length - 1) {
    currentQuestionIndex++;
    window.renderApp();
  } else {
    quizCompleted = true;
    if (quizScore >= 4 && window.triggerCelebration) {
      window.triggerCelebration();
    }
    window.API.markWordCompleted().then(() => {
      if (window.fetchProgress) window.fetchProgress();
    });
    window.renderApp();
  }
};
