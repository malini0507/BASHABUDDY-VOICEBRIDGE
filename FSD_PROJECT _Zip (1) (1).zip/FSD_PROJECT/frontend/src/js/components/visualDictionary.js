let selectedVisualConcept = 'stack';

// Live simulation states
let simulatedStack = ['main()', 'calculateArea()', 'printResult()'];
let simulatedQueue = ['Print_Job_#1', 'Print_Job_#2', 'Print_Job_#3'];

function renderVisualDictionary(state) {
  const t = (k) => window.LangManager.t(k);
  const lang = window.LangManager.getLang();

  const concepts = [
    { id: 'stack', title: 'Stack (LIFO)', icon: '📚' },
    { id: 'queue', title: 'Queue (FIFO)', icon: '🚶' },
    { id: 'tree', title: 'Binary Search Tree', icon: '🌳' },
    { id: 'database', title: 'Relational DB (PK & FK)', icon: '🗄️' },
    { id: 'network', title: 'Network Packet Flow', icon: '🌐' },
    { id: 'neural', title: 'Artificial Neural Network', icon: '🧠' },
    { id: 'memory', title: 'Array vs Linked List', icon: '💾' }
  ];

  return `
    <div class="max-w-4xl mx-auto space-y-6 animate-fadeIn">
      
      <!-- Header -->
      <div class="bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 text-white p-6 rounded-3xl shadow-lg border border-purple-500/20">
        <div class="flex items-center justify-between">
          <div>
            <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/20 text-purple-200 text-xs font-semibold mb-2">
              <span>🎨</span>
              <span>Interactive Visual Pictorial Dictionary</span>
            </div>
            <h1 class="text-2xl font-black text-white">Visual Engineering Schematics</h1>
            <p class="text-xs text-purple-200/90 mt-1">Abstract English computer science terms visualized with live interactive simulations and vernacular explanations.</p>
          </div>
        </div>
      </div>

      <!-- Concept Pills Selector -->
      <div class="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
        ${concepts.map(c => `
          <button 
            onclick="window.selectVisualConcept('${c.id}')" 
            class="px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-2 ${
              selectedVisualConcept === c.id 
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200 ring-2 ring-indigo-400' 
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }"
          >
            <span>${c.icon}</span>
            <span>${c.title}</span>
          </button>
        `).join('')}
      </div>

      <!-- Visual Stage -->
      <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        ${renderVisualConceptDiagram(selectedVisualConcept, lang)}
      </div>

    </div>
  `;
}

function renderVisualConceptDiagram(concept, lang) {
  // 1. STACK (Interactive LIFO Simulation)
  if (concept === 'stack') {
    return `
      <div class="space-y-6">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-xl font-extrabold text-slate-900">Stack (LIFO - Last In, First Out)</h2>
              <span class="text-xs bg-indigo-100 text-indigo-800 font-bold px-2 py-0.5 rounded-full">Linear DS</span>
            </div>
            <p class="text-xs text-slate-500 mt-0.5">The last element pushed onto the stack is the first element popped off.</p>
          </div>
          <div class="flex items-center gap-2">
            <button onclick="window.SpeechService.speak('Stack: Last in first out data structure')" class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1">
              🔊 Listen Term
            </button>
          </div>
        </div>

        <!-- Live Interactive Simulation Box -->
        <div class="bg-slate-900 text-white p-6 rounded-2xl flex flex-col items-center justify-center space-y-4 shadow-inner">
          <p class="text-xs font-bold uppercase tracking-wider text-indigo-300">Live Stack Memory Simulator</p>
          
          <!-- Stack Visual Container -->
          <div class="w-64 border-b-4 border-l-4 border-r-4 border-indigo-400 rounded-b-xl p-3 flex flex-col-reverse gap-2 min-h-[180px] bg-slate-800/80">
            ${simulatedStack.map((item, idx) => `
              <div class="p-2.5 rounded-lg text-center text-xs font-bold font-mono transition-all transform animate-fadeIn ${
                idx === simulatedStack.length - 1 
                  ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 ring-2 ring-amber-300 shadow-md' 
                  : 'bg-indigo-600 text-white'
              }">
                ${item} ${idx === simulatedStack.length - 1 ? '← [TOP]' : ''}
              </div>
            `).join('')}
            ${simulatedStack.length === 0 ? `
              <div class="text-slate-500 text-xs text-center py-12 italic">Stack is Empty (Underflow)</div>
            ` : ''}
          </div>

          <!-- Controls -->
          <div class="flex items-center gap-3 pt-2">
            <button 
              onclick="window.pushSimulatedStack()" 
              class="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs rounded-xl shadow transition-all flex items-center gap-1"
            >
              ➕ PUSH Element
            </button>
            <button 
              onclick="window.popSimulatedStack()" 
              class="px-4 py-2 bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs rounded-xl shadow transition-all flex items-center gap-1"
            >
              ➖ POP Element
            </button>
            <button 
              onclick="window.resetSimulatedStack()" 
              class="px-3 py-2 bg-slate-700 hover:bg-slate-600 text-xs text-slate-300 rounded-xl"
            >
              Reset
            </button>
          </div>
        </div>

        <!-- Bilingual Regional Explanation -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div class="p-4 bg-indigo-50/70 rounded-xl border border-indigo-100">
            <span class="font-bold text-indigo-900 block mb-1">తెలుగు వివరణ (Telugu):</span>
            <p class="text-slate-700 leading-relaxed">స్టాక్ అనేది పెళ్లిళ్లలో ప్లేట్ల దొంతర వంటిది. చివరగా పెట్టిన ప్లేట్‌ను మొదటగా తీస్తాము (LIFO - Last In First Out). కంప్యూటర్‌లో బ్రౌజర్ Back Button మరియు ప్రోగ్రామ్‌లలో Function Call Stack దీనికి ముఖ్య ఉదాహరణలు.</p>
          </div>
          <div class="p-4 bg-amber-50/70 rounded-xl border border-amber-100">
            <span class="font-bold text-amber-900 block mb-1">हिंदी व्याख्या (Hindi):</span>
            <p class="text-slate-700 leading-relaxed">स्टैक एक रैखिक डेटा संरचना है जो LIFO नियम का पालन करती है। जो डेटा अंत में डाला (Push) जाता है, वह सबसे पहले बाहर (Pop) निकाला जाता है।</p>
          </div>
        </div>
      </div>
    `;
  }

  // 2. QUEUE (Interactive FIFO Simulation)
  if (concept === 'queue') {
    return `
      <div class="space-y-6">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-xl font-extrabold text-slate-900">Queue (FIFO - First In, First Out)</h2>
              <span class="text-xs bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">Linear DS</span>
            </div>
            <p class="text-xs text-slate-500 mt-0.5">The first element entered at the Rear is the first element processed at the Front.</p>
          </div>
          <button onclick="window.SpeechService.speak('Queue: First in first out linear data structure')" class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold">
            🔊 Listen Term
          </button>
        </div>

        <!-- Queue Visual Simulation Box -->
        <div class="bg-slate-900 text-white p-6 rounded-2xl flex flex-col items-center justify-center space-y-4 shadow-inner">
          <p class="text-xs font-bold uppercase tracking-wider text-emerald-400">Live Queue Buffer Simulator</p>
          
          <div class="flex items-center gap-3 max-w-full overflow-x-auto py-4 px-2">
            <span class="text-rose-400 font-bold text-xs uppercase font-mono">← [FRONT: Dequeue]</span>
            <div class="flex items-center gap-2 border-y-2 border-indigo-400 py-3 px-4 rounded-lg bg-slate-800/80 min-w-[260px]">
              ${simulatedQueue.map((item, idx) => `
                <div class="px-3 py-2 rounded-lg text-xs font-mono font-bold whitespace-nowrap ${
                  idx === 0 
                    ? 'bg-rose-500 text-white ring-2 ring-rose-300' 
                    : 'bg-indigo-600 text-white'
                }">
                  ${item}
                </div>
              `).join('')}
              ${simulatedQueue.length === 0 ? `<span class="text-slate-500 text-xs italic">Queue is Empty</span>` : ''}
            </div>
            <span class="text-emerald-400 font-bold text-xs uppercase font-mono">[REAR: Enqueue] ←</span>
          </div>

          <div class="flex items-center gap-3">
            <button 
              onclick="window.enqueueSimulatedQueue()" 
              class="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs rounded-xl shadow transition-all"
            >
              ➕ ENQUEUE (Rear)
            </button>
            <button 
              onclick="window.dequeueSimulatedQueue()" 
              class="px-4 py-2 bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs rounded-xl shadow transition-all"
            >
              ➖ DEQUEUE (Front)
            </button>
            <button 
              onclick="window.resetSimulatedQueue()" 
              class="px-3 py-2 bg-slate-700 hover:bg-slate-600 text-xs text-slate-300 rounded-xl"
            >
              Reset
            </button>
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div class="p-4 bg-indigo-50/70 rounded-xl border border-indigo-100">
            <span class="font-bold text-indigo-900 block mb-1">తెలుగు వివరణ (Telugu):</span>
            <p class="text-slate-700 leading-relaxed">క్యూ అనేది బస్ టికెట్ కౌంటర్ లేదా సూపర్ మార్కెట్ బిల్లింగ్ వద్ద నిలబడే వరుస క్రమం వంటిది. మొదటగా వచ్చిన వారు మొదటగా సేవ పొందుతారు (FIFO - First In First Out). ప్రింటర్ స్ఫూలింగ్, నెట్‌వర్క్ ప్యాకెట్ రూటింగ్ దీని ఆధారంగా పనిచేస్తాయి.</p>
          </div>
          <div class="p-4 bg-amber-50/70 rounded-xl border border-amber-100">
            <span class="font-bold text-amber-900 block mb-1">हिंदी व्याख्या (Hindi):</span>
            <p class="text-slate-700 leading-relaxed">कतार (Queue) FIFO सिद्धांत पर कार्य करती है। पहले आने वाला कार्य पहले निष्पादित होता है।</p>
          </div>
        </div>
      </div>
    `;
  }

  // 3. BINARY SEARCH TREE (Interactive Tree Schematic)
  if (concept === 'tree') {
    return `
      <div class="space-y-6">
        <div class="flex items-center justify-between border-b border-slate-100 pb-4">
          <div>
            <h2 class="text-xl font-extrabold text-slate-900">Binary Search Tree (BST)</h2>
            <p class="text-xs text-slate-500">Left subtree holds values smaller than root; Right subtree holds values greater.</p>
          </div>
          <button onclick="window.SpeechService.speak('Binary Search Tree: Hierarchical tree data structure with logarithmic search time')" class="px-3 py-1.5 bg-slate-100 text-slate-700 rounded-lg text-xs font-semibold">
            🔊 Listen Term
          </button>
        </div>

        <div class="bg-slate-50 p-6 rounded-2xl flex flex-col items-center justify-center border border-slate-200">
          <svg class="w-full max-w-md h-60" viewBox="0 0 400 240">
            <!-- Connecting lines -->
            <line x1="200" y1="40" x2="120" y2="100" stroke="#94a3b8" stroke-width="2"/>
            <line x1="200" y1="40" x2="280" y2="100" stroke="#94a3b8" stroke-width="2"/>
            <line x1="120" y1="100" x2="80" y2="170" stroke="#94a3b8" stroke-width="2"/>
            <line x1="120" y1="100" x2="160" y2="170" stroke="#94a3b8" stroke-width="2"/>
            <line x1="280" y1="100" x2="240" y2="170" stroke="#94a3b8" stroke-width="2"/>
            <line x1="280" y1="100" x2="320" y2="170" stroke="#94a3b8" stroke-width="2"/>

            <!-- Root Node 50 -->
            <circle cx="200" cy="40" r="22" fill="#4f46e5" stroke="#3730a3" stroke-width="2"/>
            <text x="200" y="45" text-anchor="middle" font-size="12" font-weight="bold" fill="#ffffff">50 (Root)</text>

            <!-- Level 1 -->
            <circle cx="120" cy="100" r="20" fill="#06b6d4" stroke="#0891b2" stroke-width="2"/>
            <text x="120" y="105" text-anchor="middle" font-size="12" font-weight="bold" fill="#ffffff">30</text>

            <circle cx="280" cy="100" r="20" fill="#06b6d4" stroke="#0891b2" stroke-width="2"/>
            <text x="280" y="105" text-anchor="middle" font-size="12" font-weight="bold" fill="#ffffff">70</text>

            <!-- Level 2 -->
            <circle cx="80" cy="170" r="18" fill="#10b981" stroke="#059669" stroke-width="2"/>
            <text x="80" y="175" text-anchor="middle" font-size="11" font-weight="bold" fill="#ffffff">20</text>

            <circle cx="160" cy="170" r="18" fill="#10b981" stroke="#059669" stroke-width="2"/>
            <text x="160" y="175" text-anchor="middle" font-size="11" font-weight="bold" fill="#ffffff">40</text>

            <circle cx="240" cy="170" r="18" fill="#10b981" stroke="#059669" stroke-width="2"/>
            <text x="240" y="175" text-anchor="middle" font-size="11" font-weight="bold" fill="#ffffff">60</text>

            <circle cx="320" cy="170" r="18" fill="#10b981" stroke="#059669" stroke-width="2"/>
            <text x="320" y="175" text-anchor="middle" font-size="11" font-weight="bold" fill="#ffffff">80</text>

            <text x="70" y="70" font-size="11" font-weight="bold" fill="#0891b2">Left &lt; Root</text>
            <text x="290" y="70" font-size="11" font-weight="bold" fill="#0891b2">Right &gt; Root</text>
          </svg>
        </div>

        <div class="p-4 bg-indigo-50/70 rounded-xl border border-indigo-100 text-xs text-slate-700">
          <b>బైనరీ సెర్చ్ ట్రీ (BST) నియమం:</b> రూట్ నోడ్ (50) కంటే చిన్నవన్నీ ఎడమ వైపు (30, 20, 40), పెద్దవన్నీ కుడి వైపు (70, 60, 80) ఉంటాయి. దీని వలన శోధన సమయం O(log n) కి తగ్గుతుంది.
        </div>
      </div>
    `;
  }

  // 4. DATABASE: Relational DB (PK & FK)
  if (concept === 'database') {
    return `
      <div class="space-y-6">
        <div class="flex items-center justify-between border-b border-slate-100 pb-4">
          <div>
            <h2 class="text-xl font-extrabold text-slate-900">Relational Database: Primary & Foreign Keys</h2>
            <p class="text-xs text-slate-500">Establishing relationships between normalized tables without data redundancy.</p>
          </div>
          <button onclick="window.SpeechService.speak('Relational Database: Primary key uniquely identifies rows; foreign key links tables.')" class="px-3 py-1.5 bg-slate-100 text-slate-700 rounded-lg text-xs font-semibold">
            🔊 Listen Term
          </button>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <!-- Students Table -->
          <div class="border-2 border-indigo-200 rounded-2xl overflow-hidden shadow-sm bg-white">
            <div class="bg-indigo-600 text-white p-3 font-bold text-xs flex items-center justify-between">
              <span>📋 Students Table</span>
              <span class="text-[10px] bg-indigo-700 px-2 py-0.5 rounded">Parent Table</span>
            </div>
            <table class="w-full text-xs text-left">
              <thead class="bg-indigo-50 border-b border-indigo-100 font-semibold text-indigo-900">
                <tr>
                  <th class="p-2.5">student_id (PK) 🔑</th>
                  <th class="p-2.5">name</th>
                  <th class="p-2.5">branch</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                <tr class="bg-indigo-50/30">
                  <td class="p-2.5 font-bold font-mono text-indigo-700">101</td>
                  <td class="p-2.5">Goutham</td>
                  <td class="p-2.5">CSE</td>
                </tr>
                <tr>
                  <td class="p-2.5 font-bold font-mono text-indigo-700">102</td>
                  <td class="p-2.5">Priya</td>
                  <td class="p-2.5">ECE</td>
                </tr>
              </tbody>
            </table>
          </div>

          <!-- Enrollments Table -->
          <div class="border-2 border-emerald-200 rounded-2xl overflow-hidden shadow-sm bg-white">
            <div class="bg-emerald-600 text-white p-3 font-bold text-xs flex items-center justify-between">
              <span>📑 Exam_Results Table</span>
              <span class="text-[10px] bg-emerald-700 px-2 py-0.5 rounded">Child Table</span>
            </div>
            <table class="w-full text-xs text-left">
              <thead class="bg-emerald-50 border-b border-emerald-100 font-semibold text-emerald-900">
                <tr>
                  <th class="p-2.5">result_id</th>
                  <th class="p-2.5">student_id (FK) 🔗</th>
                  <th class="p-2.5">grade</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                <tr class="bg-emerald-50/30">
                  <td class="p-2.5 font-mono">R-01</td>
                  <td class="p-2.5 font-bold font-mono text-indigo-700 bg-indigo-100/70">101 ➔ Ref PK</td>
                  <td class="p-2.5 font-bold text-emerald-700">A+</td>
                </tr>
                <tr>
                  <td class="p-2.5 font-mono">R-02</td>
                  <td class="p-2.5 font-bold font-mono text-indigo-700 bg-indigo-100/70">102 ➔ Ref PK</td>
                  <td class="p-2.5 font-bold text-emerald-700">A</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="p-4 bg-indigo-50/70 rounded-xl border border-indigo-100 text-xs text-slate-700 space-y-1">
          <b>ప్రైమరీ కీ vs ఫారిన్ కీ (Primary vs Foreign Key):</b>
          <p>• <b>Primary Key (PK):</b> పట్టికలోని ప్రతి వరుసను ప్రత్యేకంగా గుర్తించే విశిష్ట కాలమ్ (student_id = 101).</p>
          <p>• <b>Foreign Key (FK):</b> ఒక పట్టికలోని సమాచారాన్ని మరొక పట్టికతో లింక్ చేసే రిఫరెన్స్ ఫీల్డ్.</p>
        </div>
      </div>
    `;
  }

  // 5. COMPUTER NETWORKS: Client-Server Packet Flow
  if (concept === 'network') {
    return `
      <div class="space-y-6">
        <div class="flex items-center justify-between border-b border-slate-100 pb-4">
          <div>
            <h2 class="text-xl font-extrabold text-slate-900">Computer Networks: Packet Journey</h2>
            <p class="text-xs text-slate-500">How an HTTP/HTTPS request travels from a student browser to the cloud server.</p>
          </div>
          <button onclick="window.SpeechService.speak('Computer Networks: Client sends request packets through router and firewall to destination server.')" class="px-3 py-1.5 bg-slate-100 text-slate-700 rounded-lg text-xs font-semibold">
            🔊 Listen Term
          </button>
        </div>

        <div class="bg-slate-900 text-white p-6 rounded-2xl flex flex-col items-center justify-center border border-slate-800">
          <svg class="w-full max-w-lg h-44" viewBox="0 0 520 160">
            <!-- Client Laptop -->
            <rect x="20" y="55" width="70" height="50" rx="8" fill="#38bdf8"/>
            <text x="55" y="85" text-anchor="middle" font-size="11" font-weight="bold" fill="#0f172a">Client</text>
            <text x="55" y="125" text-anchor="middle" font-size="9" fill="#94a3b8">Browser</text>

            <!-- Arrow 1 -->
            <path d="M95 80 L140 80" stroke="#f59e0b" stroke-width="2" stroke-dasharray="4"/>

            <!-- Router -->
            <circle cx="170" cy="80" r="25" fill="#f59e0b"/>
            <text x="170" y="84" text-anchor="middle" font-size="10" font-weight="bold" fill="#000">Router</text>
            <text x="170" y="125" text-anchor="middle" font-size="9" fill="#94a3b8">IP Routing</text>

            <!-- Arrow 2 -->
            <path d="M198 80 L245 80" stroke="#ef4444" stroke-width="2" stroke-dasharray="4"/>

            <!-- Firewall -->
            <rect x="250" y="55" width="60" height="50" rx="6" fill="#ef4444"/>
            <text x="280" y="85" text-anchor="middle" font-size="10" font-weight="bold" fill="#fff">Firewall</text>
            <text x="280" y="125" text-anchor="middle" font-size="9" fill="#94a3b8">Security</text>

            <!-- Arrow 3 -->
            <path d="M315 80 L360 80" stroke="#10b981" stroke-width="2" stroke-dasharray="4"/>

            <!-- Web Server -->
            <rect x="365" y="55" width="75" height="50" rx="8" fill="#10b981"/>
            <text x="402" y="85" text-anchor="middle" font-size="10" font-weight="bold" fill="#022c22">Node.js Server</text>
            <text x="402" y="125" text-anchor="middle" font-size="9" fill="#94a3b8">HTTP 200 OK</text>
          </svg>
        </div>

        <div class="p-4 bg-indigo-50/70 rounded-xl border border-indigo-100 text-xs text-slate-700">
          <b>నెట్‌వర్క్ ప్యాకెట్ ప్రయాణం (Packet Transmission):</b> విద్యార్థి బ్రౌజర్‌లో వెబ్‌సైట్ అడిగినప్పుడు, డేటా చిన్న చిన్న ప్యాకెట్లుగా విడిపోయి రూటర్ మరియు ఫైర్‌వాల్ రక్షణ కవచాల ద్వారా సర్వర్‌కు చేరుతుంది.
        </div>
      </div>
    `;
  }

  // 6. NEURAL NETWORK
  if (concept === 'neural') {
    return `
      <div class="space-y-6">
        <div class="flex items-center justify-between border-b border-slate-100 pb-4">
          <div>
            <h2 class="text-xl font-extrabold text-slate-900">Artificial Neural Network (ANN)</h2>
            <p class="text-xs text-slate-500">Multi-layer architecture mimicking biological neural connections.</p>
          </div>
          <button onclick="window.SpeechService.speak('Neural Network: Computational model inspired by human brain')" class="px-3 py-1.5 bg-slate-100 text-slate-700 rounded-lg text-xs font-semibold">
            🔊 Listen Term
          </button>
        </div>

        <div class="bg-slate-50 p-6 rounded-2xl flex flex-col items-center justify-center border border-slate-200">
          <svg class="w-full max-w-md h-56" viewBox="0 0 400 200">
            <!-- Lines -->
            <line x1="70" y1="50" x2="200" y2="40" stroke="#cbd5e1" stroke-width="1.5"/>
            <line x1="70" y1="50" x2="200" y2="100" stroke="#cbd5e1" stroke-width="1.5"/>
            <line x1="70" y1="50" x2="200" y2="160" stroke="#cbd5e1" stroke-width="1.5"/>

            <line x1="70" y1="150" x2="200" y2="40" stroke="#cbd5e1" stroke-width="1.5"/>
            <line x1="70" y1="150" x2="200" y2="100" stroke="#cbd5e1" stroke-width="1.5"/>
            <line x1="70" y1="150" x2="200" y2="160" stroke="#cbd5e1" stroke-width="1.5"/>

            <line x1="200" y1="40" x2="330" y2="100" stroke="#818cf8" stroke-width="2"/>
            <line x1="200" y1="100" x2="330" y2="100" stroke="#818cf8" stroke-width="2"/>
            <line x1="200" y1="160" x2="330" y2="100" stroke="#818cf8" stroke-width="2"/>

            <!-- Input Nodes -->
            <circle cx="70" cy="50" r="16" fill="#0284c7"/>
            <circle cx="70" cy="150" r="16" fill="#0284c7"/>
            <text x="70" y="54" text-anchor="middle" font-size="10" font-weight="bold" fill="#fff">x₁</text>
            <text x="70" y="154" text-anchor="middle" font-size="10" font-weight="bold" fill="#fff">x₂</text>
            <text x="70" y="190" text-anchor="middle" font-size="10" font-weight="bold" fill="#0369a1">Inputs</text>

            <!-- Hidden Nodes -->
            <circle cx="200" cy="40" r="16" fill="#4f46e5"/>
            <circle cx="200" cy="100" r="16" fill="#4f46e5"/>
            <circle cx="200" cy="160" r="16" fill="#4f46e5"/>
            <text x="200" y="44" text-anchor="middle" font-size="10" font-weight="bold" fill="#fff">h₁</text>
            <text x="200" y="104" text-anchor="middle" font-size="10" font-weight="bold" fill="#fff">h₂</text>
            <text x="200" y="164" text-anchor="middle" font-size="10" font-weight="bold" fill="#fff">h₃</text>
            <text x="200" y="190" text-anchor="middle" font-size="10" font-weight="bold" fill="#4338ca">Hidden Layer</text>

            <!-- Output Node -->
            <circle cx="330" cy="100" r="18" fill="#10b981"/>
            <text x="330" y="104" text-anchor="middle" font-size="11" font-weight="bold" fill="#fff">ŷ</text>
            <text x="330" y="190" text-anchor="middle" font-size="10" font-weight="bold" fill="#047857">Output</text>
          </svg>
        </div>

        <div class="p-4 bg-indigo-50/70 rounded-xl border border-indigo-100 text-xs text-slate-700">
          <b>న్యూరల్ నెట్‌వర్క్ (Neural Network):</b> మానవ మెదడులోని న్యూరాన్ల ప్రేరణతో పనిచేస్తుంది. ఇన్పుట్ లేయర్ డేటాను తీసుకుంటుంది, హిడెన్ లేయర్లు వెయిట్స్ (Weights) ద్వారా ఫీచర్లను నేర్చుకుంటాయి, అవుట్‌పుట్ లేయర్ ఫలితాన్ని అంచనా వేస్తుంది.
        </div>
      </div>
    `;
  }

  // 7. ARRAY VS LINKED LIST
  return `
    <div class="space-y-6">
      <div class="flex items-center justify-between border-b border-slate-100 pb-4">
        <div>
          <h2 class="text-xl font-extrabold text-slate-900">Memory Allocation: Array vs Linked List</h2>
          <p class="text-xs text-slate-500">Contiguous blocks in memory vs dynamically linked node pointers.</p>
        </div>
      </div>

      <div class="space-y-4">
        <!-- Array -->
        <div class="p-4 bg-slate-50 rounded-xl border border-slate-200">
          <span class="font-bold text-slate-900 text-xs block mb-2">1. Array (Contiguous Memory Blocks, Fixed Size O(1) Index Access):</span>
          <div class="flex items-center gap-1 overflow-x-auto">
            ${[10, 20, 30, 40, 50].map((val, idx) => `
              <div class="flex flex-col items-center">
                <span class="text-[10px] text-slate-400 font-mono">idx: [${idx}]</span>
                <div class="w-14 h-12 rounded bg-indigo-100 border-2 border-indigo-300 flex items-center justify-center font-bold text-xs text-indigo-900">
                  ${val}
                </div>
                <span class="text-[9px] text-slate-500 font-mono mt-0.5">0x10${idx * 4}</span>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Linked List -->
        <div class="p-4 bg-slate-50 rounded-xl border border-slate-200">
          <span class="font-bold text-slate-900 text-xs block mb-2">2. Linked List (Non-Contiguous Dynamic Nodes with Pointers):</span>
          <div class="flex items-center gap-2 overflow-x-auto">
            ${[10, 20, 30].map(val => `
              <div class="flex items-center">
                <div class="flex border-2 border-emerald-400 rounded-lg overflow-hidden bg-white shadow-sm">
                  <div class="px-3 py-2 bg-emerald-50 text-emerald-900 font-bold text-xs">${val}</div>
                  <div class="px-2 py-2 bg-emerald-200 text-emerald-950 font-mono text-[10px]">next*</div>
                </div>
                <span class="text-emerald-600 font-bold px-2 text-sm">➔</span>
              </div>
            `).join('')}
            <div class="px-2 py-1 bg-slate-200 text-slate-600 rounded text-xs font-mono">NULL</div>
          </div>
        </div>
      </div>
    </div>
  `;
}

window.renderVisualDictionary = renderVisualDictionary;

window.selectVisualConcept = (id) => {
  selectedVisualConcept = id;
  window.renderApp();
};

// Stack Simulation Handlers
window.pushSimulatedStack = () => {
  const samples = ['processData()', 'validateInput()', 'fetchRecords()', 'renderDashboard()', 'handleEvent()'];
  if (simulatedStack.length >= 5) {
    alert('Stack Overflow! Maximum demonstration capacity reached.');
    return;
  }
  const nextItem = samples[Math.floor(Math.random() * samples.length)];
  simulatedStack.push(nextItem);
  window.renderApp();
};

window.popSimulatedStack = () => {
  if (simulatedStack.length === 0) {
    alert('Stack Underflow! Stack is completely empty.');
    return;
  }
  simulatedStack.pop();
  window.renderApp();
};

window.resetSimulatedStack = () => {
  simulatedStack = ['main()', 'calculateArea()', 'printResult()'];
  window.renderApp();
};

// Queue Simulation Handlers
window.enqueueSimulatedQueue = () => {
  if (simulatedQueue.length >= 6) {
    alert('Queue Buffer is Full! Dequeue an element first.');
    return;
  }
  simulatedQueue.push(`Job_#${Math.floor(Math.random() * 80 + 10)}`);
  window.renderApp();
};

window.dequeueSimulatedQueue = () => {
  if (simulatedQueue.length === 0) {
    alert('Queue is Empty!');
    return;
  }
  simulatedQueue.shift();
  window.renderApp();
};

window.resetSimulatedQueue = () => {
  simulatedQueue = ['Print_Job_#1', 'Print_Job_#2', 'Print_Job_#3'];
  window.renderApp();
};
