function renderVocabulary(state) {
  const t = (k) => window.LangManager.t(k);
  const lang = window.LangManager.getLang();
  let words = state.vocabularyList || [];

  // Client-side filtering if user searched or filtered
  if (state.searchQuery) {
    const q = state.searchQuery.toLowerCase().trim();
    words = words.filter(w => 
      w.english_word.toLowerCase().includes(q) ||
      (w.phonetic_guide && w.phonetic_guide.toLowerCase().includes(q)) ||
      (w.telugu_meaning && w.telugu_meaning.toLowerCase().includes(q)) ||
      (w.hindi_meaning && w.hindi_meaning.toLowerCase().includes(q)) ||
      (w.tamil_meaning && w.tamil_meaning.toLowerCase().includes(q)) ||
      (w.definition && w.definition.toLowerCase().includes(q))
    );
  }

  if (state.selectedCategory && state.selectedCategory !== 'All') {
    words = words.filter(w => w.category === state.selectedCategory);
  }

  if (state.selectedDifficulty && state.selectedDifficulty !== 'All') {
    words = words.filter(w => w.difficulty === state.selectedDifficulty);
  }

  return `
    <div class="space-y-6 animate-fadeIn">
      
      <!-- Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 class="text-2xl sm:text-3xl font-black text-slate-900">${t('navVocabulary')}</h1>
          <p class="text-xs text-slate-500 mt-1">Curated dictionary of 50+ core engineering terms with phonetic guides and regional translations.</p>
        </div>

        <div class="text-xs font-bold text-slate-700 bg-white border border-slate-200 px-3.5 py-1.5 rounded-xl shadow-sm self-start sm:self-auto">
          Showing <span class="text-indigo-600 font-extrabold">${words.length}</span> Vocabulary Terms
        </div>
      </div>

      <!-- Search & Filters Bar -->
      <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        
        <!-- Search Field -->
        <div class="relative flex-1">
          <input 
            type="text" 
            placeholder="${t('searchPlaceholder')}" 
            value="${state.searchQuery || ''}"
            oninput="window.handleSearchInput(this.value)"
            class="w-full text-xs sm:text-sm pl-9 pr-4 py-2.5 bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900"
          />
          <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
            </svg>
          </div>
        </div>

        <!-- Filter Dropdowns -->
        <div class="flex items-center gap-2 flex-wrap">
          
          <select 
            onchange="window.filterVocabCategory(this.value)" 
            class="text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
          >
            <option value="All" ${state.selectedCategory === 'All' ? 'selected' : ''}>${t('categoryAll')}</option>
            <option value="Computer Fundamentals" ${state.selectedCategory === 'Computer Fundamentals' ? 'selected' : ''}>Computer Fundamentals</option>
            <option value="Programming Languages" ${state.selectedCategory === 'Programming Languages' ? 'selected' : ''}>Programming Languages</option>
            <option value="Data Structures" ${state.selectedCategory === 'Data Structures' ? 'selected' : ''}>Data Structures</option>
            <option value="Database Systems" ${state.selectedCategory === 'Database Systems' ? 'selected' : ''}>Database Systems</option>
            <option value="Computer Networks" ${state.selectedCategory === 'Computer Networks' ? 'selected' : ''}>Computer Networks</option>
            <option value="Artificial Intelligence" ${state.selectedCategory === 'Artificial Intelligence' ? 'selected' : ''}>Artificial Intelligence</option>
            <option value="Engineering Mathematics" ${state.selectedCategory === 'Engineering Mathematics' ? 'selected' : ''}>Engineering Mathematics</option>
          </select>

          <select 
            onchange="window.filterVocabDifficulty(this.value)" 
            class="text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
          >
            <option value="All" ${state.selectedDifficulty === 'All' ? 'selected' : ''}>${t('difficultyAll')}</option>
            <option value="Beginner" ${state.selectedDifficulty === 'Beginner' ? 'selected' : ''}>Beginner</option>
            <option value="Intermediate" ${state.selectedDifficulty === 'Intermediate' ? 'selected' : ''}>Intermediate</option>
            <option value="Advanced" ${state.selectedDifficulty === 'Advanced' ? 'selected' : ''}>Advanced</option>
          </select>

        </div>

      </div>

      <!-- Words Card Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        ${words.map(w => {
          let regional = w.telugu_meaning;
          if (lang === 'hi') regional = w.hindi_meaning;
          if (lang === 'ta') regional = w.tamil_meaning;
          if (lang === 'en') regional = w.definition;

          return `
            <div class="bg-white rounded-2xl p-5 border border-slate-200 hover:border-indigo-300 hover:shadow-lg transition-all flex flex-col justify-between space-y-3 group">
              
              <div>
                <div class="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <span class="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                      w.difficulty === 'Beginner' ? 'bg-emerald-100 text-emerald-800' :
                      w.difficulty === 'Intermediate' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                    }">
                      ${w.difficulty}
                    </span>
                    <span class="text-[10px] text-slate-500 font-semibold ml-1.5">
                      ${w.category}
                    </span>
                  </div>

                  <button 
                    onclick="window.SpeechService.speak('${w.english_word.replace(/'/g, "\\'")}')" 
                    class="p-2 rounded-lg bg-slate-50 text-indigo-600 hover:bg-indigo-50 border border-slate-200 shadow-sm transition-all"
                    title="Pronounce Word"
                  >
                    🔊
                  </button>
                </div>

                <h3 class="text-xl font-black text-slate-900 group-hover:text-indigo-600 transition-colors">
                  ${w.english_word}
                </h3>
                <p class="text-xs text-indigo-700 font-mono font-semibold mb-2">${w.phonetic_guide}</p>

                <!-- Regional Meaning Box -->
                <div class="bg-slate-50 p-3 rounded-xl border border-slate-100 mb-2">
                  <p class="text-xs font-bold text-slate-800 leading-snug">
                    ${regional}
                  </p>
                </div>

                <p class="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                  ${w.definition}
                </p>
              </div>

              <!-- Footer Actions -->
              <div class="pt-2 border-t border-slate-100 flex items-center justify-between">
                <button 
                  onclick="window.openVoiceLabForWord('${w.english_word.replace(/'/g, "\\'")}', ${w.word_id})" 
                  class="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                >
                  🎙️ Voice Practice &rarr;
                </button>

                <button 
                  onclick="window.markLearned(${w.word_id})" 
                  class="text-xs text-slate-500 hover:text-emerald-700 font-medium px-2 py-1 rounded bg-slate-50 hover:bg-emerald-50 transition-colors"
                >
                  ✓ Learned
                </button>
              </div>

            </div>
          `;
        }).join('')}
      </div>

    </div>
  `;
}

window.renderVocabulary = renderVocabulary;

window.handleSearchInput = (val) => {
  if (!window.appState) return;
  window.appState.searchQuery = val;
  window.renderApp();
};

window.filterVocabCategory = (cat) => {
  if (!window.appState) return;
  window.appState.selectedCategory = cat;
  window.renderApp();
};

window.filterVocabDifficulty = (diff) => {
  if (!window.appState) return;
  window.appState.selectedDifficulty = diff;
  window.renderApp();
};
